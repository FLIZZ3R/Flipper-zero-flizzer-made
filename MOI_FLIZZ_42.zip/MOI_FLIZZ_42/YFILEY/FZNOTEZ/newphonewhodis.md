ap scan report for bruce.kesslersystemsinc.com (45.15.164.191)
Host is up (0.15s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (87%), Dell 1815dn printer (87%), VxWorks (87%), IBM OS/2 Warp 2.0 (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   501.83 ms bruce.kesslersystemsinc.com (45.15.164.191)

Nmap scan report for reid.kesslersystemsinc.com (45.15.164.192)
Host is up (0.095s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.78 ms reid.kesslersystemsinc.com (45.15.164.192)

Nmap scan report for jacobson.kesslersystemsinc.com (45.15.164.193)
Host is up (0.095s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (97%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Sling embedded (88%), Linux (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/h:slingmedia:slingbox_av cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.77 ms jacobson.kesslersystemsinc.com (45.15.164.193)

Nmap scan report for schoonerimagine.com (45.15.164.194)
Host is up (0.14s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   501.80 ms schoonerimagine.com (45.15.164.194)

Nmap scan report for walters.schoonerimagine.com (45.15.164.195)
Host is up (0.088s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (97%), Oracle Virtualbox (96%), Allied Telesyn embedded (89%), Bay Networks embedded (89%), Sling embedded (88%), Linux (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:alliedtelesyn:at-9006 cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (96%), Allied Telesyn AT-9006SX/SC switch (89%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.67 ms walters.schoonerimagine.com (45.15.164.195)

Nmap scan report for brewer.schoonerimagine.com (45.15.164.196)
Host is up (0.11s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (87%), Dell 1815dn printer (87%), VxWorks (87%), IBM OS/2 Warp 2.0 (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.60 ms brewer.schoonerimagine.com (45.15.164.196)

Nmap scan report for riley.schoonerimagine.com (45.15.164.197)
Host is up (0.12s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.58 ms riley.schoonerimagine.com (45.15.164.197)

Nmap scan report for butler.schoonerimagine.com (45.15.164.198)
Host is up (0.12s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.58 ms butler.schoonerimagine.com (45.15.164.198)

Nmap scan report for stevens.schoonerimagine.com (45.15.164.199)
Host is up (0.12s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (88%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.56 ms stevens.schoonerimagine.com (45.15.164.199)

Nmap scan report for walker.schoonerimagine.com (45.15.164.200)
Host is up (0.100s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy   Squid http proxy
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (89%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   230.52 ms walker.schoonerimagine.com (45.15.164.200)

Nmap scan report for davila.schoonerimagine.com (45.15.164.201)
Host is up (0.13s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE      VERSION
25/tcp   filtered smtp
80/tcp   open     http         squid
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     sunwebadmin?
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   179.05 ms davila.schoonerimagine.com (45.15.164.201)

Nmap scan report for jordan.schoonerimagine.com (45.15.164.202)
Host is up (0.10s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (87%), Dell 1815dn printer (87%), VxWorks (87%), IBM OS/2 Warp 2.0 (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.98 ms jordan.schoonerimagine.com (45.15.164.202)

Nmap scan report for oneill.schoonerimagine.com (45.15.164.203)
Host is up (0.100s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (89%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.92 ms oneill.schoonerimagine.com (45.15.164.203)

Nmap scan report for gomez.schoonerimagine.com (45.15.164.204)
Host is up (0.13s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.96 ms gomez.schoonerimagine.com (45.15.164.204)

Nmap scan report for griffin.schoonerimagine.com (45.15.164.205)
Host is up (0.096s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.89 ms griffin.schoonerimagine.com (45.15.164.205)

Nmap scan report for morris.schoonerimagine.com (45.15.164.206)
Host is up (0.096s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Konica Minolta 7035 printer (89%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (87%), Oki B930 printer (87%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.80 ms morris.schoonerimagine.com (45.15.164.206)

Nmap scan report for ponce.schoonerimagine.com (45.15.164.207)
Host is up (0.14s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (89%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   491.03 ms ponce.schoonerimagine.com (45.15.164.207)

Nmap scan report for roberts.schoonerimagine.com (45.15.164.208)
Host is up (0.100s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.78 ms roberts.schoonerimagine.com (45.15.164.208)

Nmap scan report for rogers.schoonerimagine.com (45.15.164.209)
Host is up (0.086s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|printer
Running (JUST GUESSING): QEMU (97%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Linux (88%), Samsung embedded (88%), Dell embedded (87%), Wind River VxWorks (87%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:samsung:clp-315w cpe:/h:dell:1815dn cpe:/o:windriver:vxworks
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (88%), Dell 1815dn printer (87%), VxWorks (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.74 ms rogers.schoonerimagine.com (45.15.164.209)

Nmap scan report for lester.schoonerimagine.com (45.15.164.210)
Host is up (0.10s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   178.75 ms lester.schoonerimagine.com (45.15.164.210)

Nmap scan report for newman.schoonerimagine.com (45.15.164.211)
Host is up (0.093s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   233.13 ms newman.schoonerimagine.com (45.15.164.211)

Nmap scan report for burns.schoonerimagine.com (45.15.164.212)
Host is up (0.11s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (88%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   233.03 ms burns.schoonerimagine.com (45.15.164.212)

Nmap scan report for wagner.schoonerimagine.com (45.15.164.213)
Host is up (0.13s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   233.09 ms wagner.schoonerimagine.com (45.15.164.213)

Nmap scan report for anderson.schoonerimagine.com (45.15.164.214)
Host is up (0.14s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (87%), Dell 1815dn printer (87%), VxWorks (87%), IBM OS/2 Warp 2.0 (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   233.07 ms anderson.schoonerimagine.com (45.15.164.214)

Nmap scan report for faulkner.schoonerimagine.com (45.15.164.215)
Host is up (0.12s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (88%), Konica Minolta 7035 printer (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   232.98 ms faulkner.schoonerimagine.com (45.15.164.215)

Nmap scan report for fox.schoonerimagine.com (45.15.164.216)
Host is up (0.11s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   232.95 ms fox.schoonerimagine.com (45.15.164.216)

Nmap scan report for lee.schoonerimagine.com (45.15.164.217)
Host is up (0.14s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   232.94 ms lee.schoonerimagine.com (45.15.164.217)

Nmap scan report for proctor.schoonerimagine.com (45.15.164.218)
Host is up (0.11s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   232.92 ms proctor.schoonerimagine.com (45.15.164.218)

Nmap scan report for beltran.schoonerimagine.com (45.15.164.219)
Host is up (0.11s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (87%), Dell 1815dn printer (87%), VxWorks (87%), IBM OS/2 Warp 2.0 (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   232.90 ms beltran.schoonerimagine.com (45.15.164.219)

Nmap scan report for watson.schoonerimagine.com (45.15.164.220)
Host is up (0.10s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (89%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   232.89 ms watson.schoonerimagine.com (45.15.164.220)

Nmap scan report for howe.schoonerimagine.com (45.15.164.221)
Host is up (0.096s latency).
Not shown: 996 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.78 ms howe.schoonerimagine.com (45.15.164.221)

Nmap scan report for fischer.schoonerimagine.com (45.15.164.222)
Host is up (0.094s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.72 ms fischer.schoonerimagine.com (45.15.164.222)

Nmap scan report for novak.schoonerimagine.com (45.15.164.223)
Host is up (0.10s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (93%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.65 ms novak.schoonerimagine.com (45.15.164.223)

Nmap scan report for arnold.schoonerimagine.com (45.15.164.224)
Host is up (0.12s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.70 ms arnold.schoonerimagine.com (45.15.164.224)

Nmap scan report for cummings.schoonerimagine.com (45.15.164.225)
Host is up (0.11s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Allied Telesyn AT-9006SX/SC switch (87%), Konica Minolta 7035 printer (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), GNU Hurd 0.3 (87%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.56 ms cummings.schoonerimagine.com (45.15.164.225)

Nmap scan report for bartlett.schoonerimagine.com (45.15.164.226)
Host is up (0.091s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.52 ms bartlett.schoonerimagine.com (45.15.164.226)

Nmap scan report for ochoa.schoonerimagine.com (45.15.164.227)
Host is up (0.072s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Slingmedia Slingbox AV TV over IP gateway (88%), Konica Minolta 7035 printer (88%), GNU Hurd 0.3 (88%), Nortel BNT Ethernet switch module (86%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (86%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.50 ms ochoa.schoonerimagine.com (45.15.164.227)

Nmap scan report for garner.schoonerimagine.com (45.15.164.228)
Host is up (0.088s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Konica Minolta 7035 printer (87%), GNU Hurd 0.3 (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.51 ms garner.schoonerimagine.com (45.15.164.228)

Nmap scan report for alvarado.schoonerimagine.com (45.15.164.229)
Host is up (0.081s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Konica Minolta 7035 printer (87%), GNU Hurd 0.3 (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.47 ms alvarado.schoonerimagine.com (45.15.164.229)

Nmap scan report for mccarty.schoonerimagine.com (45.15.164.230)
Host is up (0.093s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   172.48 ms mccarty.schoonerimagine.com (45.15.164.230)

Nmap scan report for perez.schoonerimagine.com (45.15.164.231)
Host is up (0.13s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Konica Minolta 7035 printer (87%), GNU Hurd 0.3 (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   412.82 ms perez.schoonerimagine.com (45.15.164.231)

Nmap scan report for adkins.schoonerimagine.com (45.15.164.232)
Host is up (0.16s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Konica Minolta 7035 printer (87%), GNU Hurd 0.3 (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   412.76 ms adkins.schoonerimagine.com (45.15.164.232)

Nmap scan report for yoder.schoonerimagine.com (45.15.164.233)
Host is up (0.16s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   412.70 ms yoder.schoonerimagine.com (45.15.164.233)

Nmap scan report for mccall.schoonerimagine.com (45.15.164.234)
Host is up (0.17s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   412.73 ms mccall.schoonerimagine.com (45.15.164.234)

Nmap scan report for fitzpatrick.schoonerimagine.com (45.15.164.235)
Host is up (0.13s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   412.13 ms fitzpatrick.schoonerimagine.com (45.15.164.235)

Nmap scan report for jefferson.schoonerimagine.com (45.15.164.236)
Host is up (0.13s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (89%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   412.06 ms jefferson.schoonerimagine.com (45.15.164.236)

Nmap scan report for daniels.schoonerimagine.com (45.15.164.237)
Host is up (0.13s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (87%), Dell 1815dn printer (87%), VxWorks (87%), IBM OS/2 Warp 2.0 (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   412.04 ms daniels.schoonerimagine.com (45.15.164.237)

Nmap scan report for patel.schoonerimagine.com (45.15.164.238)
Host is up (0.14s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   411.64 ms patel.schoonerimagine.com (45.15.164.238)

Nmap scan report for stone.schoonerimagine.com (45.15.164.239)
Host is up (0.15s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (87%), Dell 1815dn printer (87%), VxWorks (87%), IBM OS/2 Warp 2.0 (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   411.57 ms stone.schoonerimagine.com (45.15.164.239)

Nmap scan report for evans.schoonerimagine.com (45.15.164.240)
Host is up (0.12s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (93%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), GNU Hurd 0.3 (88%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   411.54 ms evans.schoonerimagine.com (45.15.164.240)

Nmap scan report for young.schoonerimagine.com (45.15.164.241)
Host is up (0.091s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   191.06 ms young.schoonerimagine.com (45.15.164.241)

Nmap scan report for heath.schoonerimagine.com (45.15.164.242)
Host is up (0.11s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   190.99 ms heath.schoonerimagine.com (45.15.164.242)

Nmap scan report for austin.schoonerimagine.com (45.15.164.243)
Host is up (0.091s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (97%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Sling embedded (88%), Linux (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/h:slingmedia:slingbox_av cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   190.94 ms austin.schoonerimagine.com (45.15.164.243)

Nmap scan report for mora.schoonerimagine.com (45.15.164.244)
Host is up (0.096s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   190.98 ms mora.schoonerimagine.com (45.15.164.244)

Nmap scan report for banks.schoonerimagine.com (45.15.164.245)
Host is up (0.089s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   190.90 ms banks.schoonerimagine.com (45.15.164.245)

Nmap scan report for black.schoonerimagine.com (45.15.164.246)
Host is up (0.095s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), HP 9100c Digital Sender printer (J3113A) (87%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   190.79 ms black.schoonerimagine.com (45.15.164.246)

Nmap scan report for russo.schoonerimagine.com (45.15.164.247)
Host is up (0.14s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   490.96 ms russo.schoonerimagine.com (45.15.164.247)

Nmap scan report for fuentes.schoonerimagine.com (45.15.164.248)
Host is up (0.100s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (88%), IBM OS/2 Warp 2.0 (87%), Dell 1815dn printer (87%), VxWorks (87%), Xerox WorkCentre 4150 printer (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   190.62 ms fuentes.schoonerimagine.com (45.15.164.248)

Nmap scan report for shepherd.schoonerimagine.com (45.15.164.249)
Host is up (0.12s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   190.15 ms shepherd.schoonerimagine.com (45.15.164.249)

Nmap scan report for rasmussen.schoonerimagine.com (45.15.164.250)
Host is up (0.11s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   189.82 ms rasmussen.schoonerimagine.com (45.15.164.250)

Nmap scan report for huff.schoonerimagine.com (45.15.164.251)
Host is up (0.084s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   118.08 ms huff.schoonerimagine.com (45.15.164.251)

Nmap scan report for 45.15.164.252
Host is up (0.084s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     tcpwrapped
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     tcpwrapped
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     tcpwrapped
Aggressive OS guesses: QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   119.70 ms 45.15.164.252

Nmap scan report for 45.15.164.253
Host is up (0.098s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     rpcbind    2-4 (RPC #100000)
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     http-proxy Squid http proxy
|_http-title: ERROR: The requested URL could not be retrieved
|_http-server-header: squid
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (88%), Slingmedia Slingbox AV TV over IP gateway (88%), GNU Hurd 0.3 (88%), Allied Telesyn AT-9006SX/SC switch (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Oki B711 printer (86%), Oki B930 printer (86%), HP 9100c Digital Sender printer (J3113A) (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   119.64 ms 45.15.164.253

Nmap scan report for bird.schoonerimagine.com (45.15.164.254)
Host is up (0.12s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE    SERVICE    VERSION
25/tcp   filtered smtp
80/tcp   open     http-proxy Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
111/tcp  open     rpcbind    2-4 (RPC #100000)
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
5431/tcp filtered park-agent
8800/tcp open     http-proxy Squid http proxy
|_http-server-header: squid
|_http-title: ERROR: The requested URL could not be retrieved
Aggressive OS guesses: QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Konica Minolta 7035 printer (89%), Allied Telesyn AT-9006SX/SC switch (88%), GNU Hurd 0.3 (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.113
2   122.63 ms bird.schoonerimagine.com (45.15.164.254)

RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
Warning: 45.15.165.34 giving up on port because retransmissio
ap scan report for 45.15.164.255
Host is up (0.0022s latency).
All 1000 scanned ports on 45.15.164.255 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-17 are the same as for 45.15.164.142
18  ... 30

Nmap scan report for 45.15.165.0
Host is up (0.0022s latency).
All 1000 scanned ports on 45.15.165.0 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-8 are the same as for 45.15.165.60
9   ... 30

Nmap scan report for 45.15.165.1
Host is up (0.16s latency).
All 1000 scanned ports on 45.15.165.1 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 9 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-8 are the same as for 45.15.165.60
9   129.05 ms 45.15.165.1

Nmap scan report for sweetenth.com (45.15.165.2)
Host is up (0.12s latency).
Not shown: 989 closed tcp ports (reset)
PORT     STATE    SERVICE        VERSION
22/tcp   open     ssh            OpenSSH 8.0 (protocol 2.0)
| ssh-hostkey: 
|   3072 3e77cd550fdc4679b8c7aea8aa4a7a67 (RSA)
|   256 ee6b9c8445d2387e0906a3fa6e346972 (ECDSA)
|_  256 074da70dcd17a60399b77682af4441c0 (ED25519)
25/tcp   filtered smtp
111/tcp  open     rpcbind        2-4 (RPC #100000)
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|_  100000  3,4          111/udp6  rpcbind
515/tcp  filtered printer
3013/tcp filtered gilatskysurfer
5431/tcp filtered park-agent
5550/tcp filtered sdadmind
5925/tcp open     vnc            VNC (protocol 3.8)
| vnc-info: 
|   Protocol version: 3.8
|   Security types: 
|_    VNC Authentication (2)
5952/tcp open     vnc            VNC (protocol 3.8)
| vnc-info: 
|   Protocol version: 3.8
|   Security types: 
|_    VNC Authentication (2)
7443/tcp filtered oracleas-https
8291/tcp filtered unknown
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (97%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Allied Telesyn embedded (89%), Sling embedded (88%), Linux (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/h:slingmedia:slingbox_av cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   95.49 ms sweetenth.com (45.15.165.2)

Nmap scan report for abbv.sweetenth.com (45.15.165.3)
Host is up (0.0021s latency).
All 1000 scanned ports on abbv.sweetenth.com (45.15.165.3) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for emudd.sweetenth.com (45.15.165.4)
Host is up (0.0018s latency).
All 1000 scanned ports on emudd.sweetenth.com (45.15.165.4) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for 3thebiglebowski.sweetenth.com (45.15.165.5)
Host is up (0.00041s latency).
All 1000 scanned ports on 3thebiglebowski.sweetenth.com (45.15.165.5) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for nogle.sweetenth.com (45.15.165.6)
Host is up (0.00026s latency).
All 1000 scanned ports on nogle.sweetenth.com (45.15.165.6) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-8 are the same as for 45.15.165.60
9   71.56 ms 23.147.224.126
10  ... 30

Nmap scan report for explainst.com (45.15.165.7)
Host is up (0.00020s latency).
All 1000 scanned ports on explainst.com (45.15.165.7) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for manets.explainst.com (45.15.165.8)
Host is up (0.00014s latency).
All 1000 scanned ports on manets.explainst.com (45.15.165.8) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for muav.explainst.com (45.15.165.9)
Host is up (0.00023s latency).
All 1000 scanned ports on muav.explainst.com (45.15.165.9) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for udhamr.explainst.com (45.15.165.10)
Host is up (0.061s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE    VERSION
3389/tcp open  tcpwrapped
| ssl-cert: Subject: commonName=FireVPS-RDP
| Not valid before: 2023-01-04T13:24:37
|_Not valid after:  2023-07-06T13:24:37
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 3389/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   70.14 ms udhamr.explainst.com (45.15.165.10)

Nmap scan report for ranska.explainst.com (45.15.165.11)
Host is up (0.11s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE            VERSION
3389/tcp open  ssl/ms-wbt-server?
|_ssl-date: 2023-02-24T06:46:32+00:00; +1m23s from scanner time.
| ssl-cert: Subject: commonName=FireVPS-RDP
| Not valid before: 2023-01-23T13:43:54
|_Not valid after:  2023-07-25T13:43:54
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

Host script results:
|_clock-skew: 1m22s

TRACEROUTE (using port 3389/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   70.04 ms ranska.explainst.com (45.15.165.11)

Nmap scan report for elementatisland.bid (45.15.165.12)
Host is up (0.00028s latency).
All 1000 scanned ports on elementatisland.bid (45.15.165.12) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for offsid.elementatisland.bid (45.15.165.13)
Host is up (0.11s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE    VERSION
3389/tcp open  tcpwrapped
|_ssl-date: 2023-02-24T06:46:29+00:00; +1m22s from scanner time.
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

Host script results:
|_clock-skew: 1m21s

TRACEROUTE (using port 3389/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   73.27 ms offsid.elementatisland.bid (45.15.165.13)

Nmap scan report for jefes.elementatisland.bid (45.15.165.14)
Host is up (0.00035s latency).
All 1000 scanned ports on jefes.elementatisland.bid (45.15.165.14) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for dsfald.elementatisland.bid (45.15.165.15)
Host is up (0.00024s latency).
All 1000 scanned ports on dsfald.elementatisland.bid (45.15.165.15) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for lacing.elementatisland.bid (45.15.165.16)
Host is up (0.00019s latency).
All 1000 scanned ports on lacing.elementatisland.bid (45.15.165.16) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for pellotin.com (45.15.165.17)
Host is up (0.096s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE            VERSION
3389/tcp open  ssl/ms-wbt-server?
|_ssl-date: 2023-02-24T06:46:17+00:00; +1m30s from scanner time.
| ssl-cert: Subject: commonName=FireVPS-RDP
| Not valid before: 2023-02-13T00:16:21
|_Not valid after:  2023-08-15T00:16:21
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

Host script results:
|_clock-skew: 1m29s

TRACEROUTE (using port 3389/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   75.02 ms pellotin.com (45.15.165.17)

Nmap scan report for escru.pellotin.com (45.15.165.18)
Host is up (0.063s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE            VERSION
3389/tcp open  ssl/ms-wbt-server?
|_ssl-date: 2023-02-24T06:45:07+00:00; +1m28s from scanner time.
| ssl-cert: Subject: commonName=FireVPS-RDP
| Not valid before: 2023-01-03T22:53:27
|_Not valid after:  2023-07-05T22:53:27
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

Host script results:
|_clock-skew: 1m27s

TRACEROUTE (using port 3389/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   98.87 ms escru.pellotin.com (45.15.165.18)

Nmap scan report for attbl.pellotin.com (45.15.165.19)
Host is up (0.11s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE SERVICE VERSION
80/tcp open  http    Microsoft IIS httpd 8.5
|_http-title: IIS Windows Server
| http-methods: 
|_  Potentially risky methods: TRACE
|_http-server-header: Microsoft-IIS/8.5
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

TRACEROUTE (using port 80/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   90.72 ms attbl.pellotin.com (45.15.165.19)

Nmap scan report for djaksa.pellotin.com (45.15.165.20)
Host is up (0.00036s latency).
All 1000 scanned ports on djaksa.pellotin.com (45.15.165.20) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for lococo.pellotin.com (45.15.165.21)
Host is up (0.00034s latency).
All 1000 scanned ports on lococo.pellotin.com (45.15.165.21) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for semicolumnar.com (45.15.165.22)
Host is up (0.00031s latency).
All 1000 scanned ports on semicolumnar.com (45.15.165.22) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for madava.semicolumnar.com (45.15.165.23)
Host is up (0.00028s latency).
All 1000 scanned ports on madava.semicolumnar.com (45.15.165.23) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for engatg.semicolumnar.com (45.15.165.24)
Host is up (0.00026s latency).
All 1000 scanned ports on engatg.semicolumnar.com (45.15.165.24) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for hsart.semicolumnar.com (45.15.165.25)
Host is up (0.063s latency).
Not shown: 998 filtered tcp ports (no-response)
PORT     STATE SERVICE            VERSION
3389/tcp open  ssl/ms-wbt-server?
| ssl-cert: Subject: commonName=FireVPS-RDP
| Not valid before: 2023-02-19T23:49:24
|_Not valid after:  2023-08-21T23:49:24
|_ssl-date: 2023-02-24T06:44:58+00:00; +1m38s from scanner time.
7070/tcp open  tcpwrapped
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

Host script results:
|_clock-skew: 1m37s

TRACEROUTE (using port 3389/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   80.50 ms hsart.semicolumnar.com (45.15.165.25)

Nmap scan report for tnodis.semicolumnar.com (45.15.165.26)
Host is up (0.058s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE            VERSION
3389/tcp open  ssl/ms-wbt-server?
| ssl-cert: Subject: commonName=FireVPS-RDP
| Not valid before: 2023-02-17T15:32:58
|_Not valid after:  2023-08-19T15:32:58
|_ssl-date: 2023-02-24T06:46:29+00:00; +1m22s from scanner time.
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (95%), Bay Networks embedded (91%), Allied Telesyn embedded (88%), Linux (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

Host script results:
|_clock-skew: 1m21s

TRACEROUTE (using port 3389/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   81.30 ms tnodis.semicolumnar.com (45.15.165.26)

Nmap scan report for 45.15.165.27
Host is up (0.00017s latency).
All 1000 scanned ports on 45.15.165.27 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for 45.15.165.28
Host is up (0.00016s latency).
All 1000 scanned ports on 45.15.165.28 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for 45.15.165.29
Host is up (0.00022s latency).
All 1000 scanned ports on 45.15.165.29 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for 45.15.165.30
Host is up (0.00038s latency).
All 1000 scanned ports on 45.15.165.30 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.6
10  ... 30

Nmap scan report for 45.15.165.31
Host is up (0.00032s latency).
All 1000 scanned ports on 45.15.165.31 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-8 are the same as for 45.15.165.60
9   ... 30

Nmap scan report for 45.15.165.32
Host is up (0.00032s latency).
All 1000 scanned ports on 45.15.165.32 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-8 are the same as for 45.15.165.38
9   ... 30

Nmap scan report for 45.15.165.33
Host is up (0.16s latency).
All 1000 scanned ports on 45.15.165.33 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 9 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-8 are the same as for 45.15.165.38
9   220.01 ms 45.15.165.33

Nmap scan report for 45.15.165.34
Host is up (0.14s latency).
Not shown: 991 closed tcp ports (reset)
PORT      STATE    SERVICE    VERSION
25/tcp    filtered smtp
1500/tcp  filtered vlsi-lm
2008/tcp  filtered conf
5280/tcp  filtered xmpp-bosh
5357/tcp  filtered wsdapi
5431/tcp  filtered park-agent
7103/tcp  filtered unknown
25735/tcp filtered unknown
52869/tcp filtered unknown
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: webcam|power-device|general purpose|PBX|router|media device
Running (JUST GUESSING): AXIS embedded (95%), CAEN embedded (95%), GNU Hurd (95%), Linux 2.0.X|2.1.X (95%), Philips embedded (95%), Sony embedded (95%)
OS CPE: cpe:/h:axis:2100_network_camera cpe:/o:gnu:hurd cpe:/o:linux:linux_kernel:2.0.33 cpe:/o:linux:linux_kernel:2.0.38 cpe:/o:linux:linux_kernel:2.0.39 cpe:/o:linux:linux_kernel:2.1.24 cpe:/h:philips:hdr112 cpe:/h:sony:svr-2000
Aggressive OS guesses: AXIS 2100 Network Camera (95%), AXIS 2120 Network Camera (95%), CAEN SY2527 high voltage power supply (95%), GNU Hurd 0.3 (95%), Linux 2.0.33 (95%), Linux 2.0.35 - 2.0.36 (95%), Linux 2.0.36 (Red Hat 5.2) (95%), Linux 2.0.39 - 2.0.40 (embedded) (95%), elmeg T240 or T444 PABX (Linux 2.0.38) (95%), FREESCO single-floppy router (Linux 2.0.39) (95%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   193.92 ms 45.15.165.34

Nmap scan report for 45.15.165.35
Host is up (0.00013s latency).
All 1000 scanned ports on 45.15.165.35 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.38
10  ... 30

Nmap scan report for 45.15.165.36
Host is up (0.00014s latency).
All 1000 scanned ports on 45.15.165.36 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.38
10  ... 30

Nmap scan report for 45.15.165.37
Host is up (0.00023s latency).
All 1000 scanned ports on 45.15.165.37 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.38
10  ... 30

Nmap scan report for 45.15.165.38
Host is up (0.00034s latency).
All 1000 scanned ports on 45.15.165.38 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-7 are the same as for 45.15.165.60
8   95.95 ms 23.147.224.15
9   70.83 ms 5.104.79.14
10  ... 30

Nmap scan report for 45.15.165.39
Host is up (0.00023s latency).
All 1000 scanned ports on 45.15.165.39 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-8 are the same as for 45.15.165.38
9   ... 30

Nmap scan report for 45.15.165.40
Host is up (0.00032s latency).
All 1000 scanned ports on 45.15.165.40 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-7 are the same as for 45.15.165.60
8   ... 30

Nmap scan report for 45.15.165.41
Host is up (0.16s latency).
All 1000 scanned ports on 45.15.165.41 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 9 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-7 are the same as for 45.15.165.60
8   ...
9   213.10 ms 45.15.165.41

Nmap scan report for 45.15.165.42
Host is up (0.100s latency).
Not shown: 995 filtered tcp ports (no-response)
PORT    STATE  SERVICE  VERSION
20/tcp  closed ftp-data
22/tcp  closed ssh
80/tcp  open   http     nginx
|_http-title: Site doesn't have a title (application/octet-stream).
|_http-trane-info: Problem with XML parsing of /evox/about
443/tcp open   ssl/http nginx
| tls-nextprotoneg: 
|   h2
|_  http/1.1
|_http-title: Did not follow redirect to https://45.15.165.42/
| tls-alpn: 
|   h2
|_  http/1.1
|_ssl-date: TLS randomness does not represent time
| ssl-cert: Subject: commonName=8ksw.com
| Subject Alternative Name: DNS:8ksw.com, DNS:m.8ksw.com, DNS:www.8ksw.com
| Not valid before: 2023-02-20T06:46:38
|_Not valid after:  2023-05-21T06:46:37
888/tcp open   http     nginx
|_http-title: 404 Not Found
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 22/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   83.51 ms 45.15.165.42

Nmap scan report for 45.15.165.43
Host is up (0.12s latency).
Not shown: 995 filtered tcp ports (no-response)
PORT    STATE  SERVICE  VERSION
20/tcp  closed ftp-data
22/tcp  closed ssh
80/tcp  open   http     nginx
|_http-title: Site doesn't have a title (application/octet-stream).
443/tcp open   ssl/http nginx
|_http-title: Site doesn't have a title (application/octet-stream).
| tls-nextprotoneg: 
|   h2
|_  http/1.1
| ssl-cert: Subject: commonName=8ksw.com
| Subject Alternative Name: DNS:8ksw.com, DNS:m.8ksw.com, DNS:www.8ksw.com
| Not valid before: 2023-02-20T06:46:38
|_Not valid after:  2023-05-21T06:46:37
| tls-alpn: 
|   h2
|_  http/1.1
888/tcp open   http     nginx
|_http-title: 404 Not Found
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (91%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 22/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   73.17 ms 45.15.165.43

Nmap scan report for 45.15.165.44
Host is up (0.26s latency).
Not shown: 996 filtered tcp ports (no-response)
PORT    STATE  SERVICE    VERSION
20/tcp  closed ftp-data
22/tcp  closed ssh
443/tcp open   ssl/http   nginx
| ssl-cert: Subject: commonName=8ksw.com
| Subject Alternative Name: DNS:8ksw.com, DNS:m.8ksw.com, DNS:www.8ksw.com
| Not valid before: 2023-02-20T06:46:38
|_Not valid after:  2023-05-21T06:46:37
| tls-alpn: 
|   h2
|_  http/1.1
|_http-title: Site doesn't have a title (application/octet-stream).
|_ssl-date: TLS randomness does not represent time
888/tcp open   tcpwrapped
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (91%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 22/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   74.45 ms 45.15.165.44

Nmap scan report for 45.15.165.45
Host is up (0.12s latency).
Not shown: 995 filtered tcp ports (no-response)
PORT    STATE  SERVICE  VERSION
20/tcp  closed ftp-data
22/tcp  closed ssh
80/tcp  open   http     nginx
|_http-title: Site doesn't have a title (application/octet-stream).
443/tcp open   ssl/http nginx
|_http-title: Did not follow redirect to https://45.15.165.45/
|_ssl-date: TLS randomness does not represent time
| tls-nextprotoneg: 
|   h2
|_  http/1.1
| tls-alpn: 
|   h2
|_  http/1.1
| ssl-cert: Subject: commonName=8ksw.com
| Subject Alternative Name: DNS:8ksw.com, DNS:m.8ksw.com, DNS:www.8ksw.com
| Not valid before: 2023-02-20T06:46:38
|_Not valid after:  2023-05-21T06:46:37
888/tcp open   http     nginx
|_http-title: 404 Not Found
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Allied Telesyn embedded (89%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (89%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 22/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   71.88 ms 45.15.165.45

Nmap scan report for 45.15.165.46
Host is up (0.11s latency).
Not shown: 995 filtered tcp ports (no-response)
PORT    STATE  SERVICE  VERSION
20/tcp  closed ftp-data
22/tcp  closed ssh
80/tcp  open   http     nginx
|_http-title: Site doesn't have a title (application/octet-stream).
443/tcp open   ssl/http nginx
| tls-nextprotoneg: 
|   h2
|_  http/1.1
| tls-alpn: 
|   h2
|_  http/1.1
|_http-title: Site doesn't have a title (application/octet-stream).
| ssl-cert: Subject: commonName=8ksw.com
| Subject Alternative Name: DNS:8ksw.com, DNS:m.8ksw.com, DNS:www.8ksw.com
| Not valid before: 2023-02-20T06:46:38
|_Not valid after:  2023-05-21T06:46:37
|_ssl-date: TLS randomness does not represent time
888/tcp open   http     nginx
|_http-title: 404 Not Found
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (91%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 22/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   71.74 ms 45.15.165.46

Nmap scan report for 45.15.165.47
Host is up (0.00042s latency).
All 1000 scanned ports on 45.15.165.47 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-7 are the same as for 45.15.165.60
8   ... 30

Nmap scan report for 45.15.165.48
Host is up (0.00033s latency).
All 1000 scanned ports on 45.15.165.48 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-7 are the same as for 45.15.165.60
8   ... 30

Nmap scan report for 45.15.165.49
Host is up (0.012s latency).
All 1000 scanned ports on 45.15.165.49 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 8 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-7 are the same as for 45.15.165.60
8   95.93 ms 45.15.165.49

Nmap scan report for 45.15.165.50
Host is up (0.23s latency).
Not shown: 991 closed tcp ports (reset)
PORT     STATE    SERVICE        VERSION
25/tcp   filtered smtp
80/tcp   open     http
| fingerprint-strings: 
|   GetRequest: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:33 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|     <li><a href="disclaimer.html"> Disclaimer </a></li>
|   HTTPOptions: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:40 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|_    <li><a href="disclaimer.html"> Disclaimer </a></li>
|_http-server-header: <empty>
|_http-title: 500 Internal Server Error
389/tcp  filtered ldap
843/tcp  filtered unknown
5431/tcp filtered park-agent
5811/tcp filtered unknown
7443/tcp filtered oracleas-https
7496/tcp filtered unknown
9618/tcp filtered condor
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port80-TCP:V=7.93%I=7%D=2/23%Time=63F855A6%P=x86_64-pc-linux-gnu%r(GetR
SF:equest,840,"HTTP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x20202
SF:3\x2006:15:33\x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIG
SF:IN\r\nX-XSS-Protection:\x201;\x20mode=block\r\nX-Content-Type-Options:\
SF:x20nosniff\r\nContent-Length:\x201869\r\nConnection:\x20close\r\nConten
SF:t-Type:\x20text/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PU
SF:BLIC\x20\"-//W3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http:
SF://www\.w3\.org/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmln
SF:s=\"http://www\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Co
SF:ntent-Type\"\x20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>G
SF:iftcomputer\.vip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/cs
SF:s\"\x20href=\"images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<
SF:body>\n<div\x20id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20hr
SF:ef=\"#\">Giftcomputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n
SF:\t<div\x20id=\"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20h
SF:ref=\"index\.html\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"priva
SF:cy\.html\">\x20Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\
SF:.html\">\x20Disclaimer\x20</a></li>\n\t\x20\x20")%r(HTTPOptions,840,"HT
SF:TP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x202023\x2006:15:40\
SF:x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIGIN\r\nX-XSS-Pr
SF:otection:\x201;\x20mode=block\r\nX-Content-Type-Options:\x20nosniff\r\n
SF:Content-Length:\x201869\r\nConnection:\x20close\r\nContent-Type:\x20tex
SF:t/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PUBLIC\x20\"-//W
SF:3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http://www\.w3\.org
SF:/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmlns=\"http://www
SF:\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Content-Type\"\x
SF:20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>Giftcomputer\.v
SF:ip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/css\"\x20href=\"
SF:images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<body>\n<div\x2
SF:0id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20href=\"#\">Giftc
SF:omputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n\t<div\x20id=\
SF:"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20href=\"index\.h
SF:tml\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"privacy\.html\">\x2
SF:0Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\.html\">\x20Di
SF:sclaimer\x20</a></li>\n\t\x20\x20");
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (91%), Allied Telesyn embedded (89%), Linux (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (89%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT      ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   69.58 ms 45.15.165.50

Nmap scan report for 45.15.165.51
Host is up (0.10s latency).
Not shown: 988 closed tcp ports (reset)
PORT      STATE    SERVICE    VERSION
25/tcp    filtered smtp
80/tcp    open     http
|_http-server-header: <empty>
| fingerprint-strings: 
|   GetRequest: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:40 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|     <li><a href="disclaimer.html"> Disclaimer </a></li>
|   HTTPOptions: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:43 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|_    <li><a href="disclaimer.html"> Disclaimer </a></li>
|_http-title: 500 Internal Server Error
801/tcp   filtered device
1007/tcp  filtered unknown
1169/tcp  filtered tripwire
1216/tcp  filtered etebac5
5061/tcp  filtered sip-tls
5431/tcp  filtered park-agent
5963/tcp  filtered indy
7920/tcp  filtered unknown
10621/tcp filtered unknown
19780/tcp filtered unknown
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port80-TCP:V=7.93%I=7%D=2/23%Time=63F855AA%P=x86_64-pc-linux-gnu%r(GetR
SF:equest,840,"HTTP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x20202
SF:3\x2006:15:40\x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIG
SF:IN\r\nX-XSS-Protection:\x201;\x20mode=block\r\nX-Content-Type-Options:\
SF:x20nosniff\r\nContent-Length:\x201869\r\nConnection:\x20close\r\nConten
SF:t-Type:\x20text/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PU
SF:BLIC\x20\"-//W3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http:
SF://www\.w3\.org/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmln
SF:s=\"http://www\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Co
SF:ntent-Type\"\x20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>G
SF:iftcomputer\.vip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/cs
SF:s\"\x20href=\"images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<
SF:body>\n<div\x20id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20hr
SF:ef=\"#\">Giftcomputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n
SF:\t<div\x20id=\"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20h
SF:ref=\"index\.html\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"priva
SF:cy\.html\">\x20Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\
SF:.html\">\x20Disclaimer\x20</a></li>\n\t\x20\x20")%r(HTTPOptions,840,"HT
SF:TP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x202023\x2006:15:43\
SF:x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIGIN\r\nX-XSS-Pr
SF:otection:\x201;\x20mode=block\r\nX-Content-Type-Options:\x20nosniff\r\n
SF:Content-Length:\x201869\r\nConnection:\x20close\r\nContent-Type:\x20tex
SF:t/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PUBLIC\x20\"-//W
SF:3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http://www\.w3\.org
SF:/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmlns=\"http://www
SF:\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Content-Type\"\x
SF:20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>Giftcomputer\.v
SF:ip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/css\"\x20href=\"
SF:images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<body>\n<div\x2
SF:0id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20href=\"#\">Giftc
SF:omputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n\t<div\x20id=\
SF:"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20href=\"index\.h
SF:tml\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"privacy\.html\">\x2
SF:0Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\.html\">\x20Di
SF:sclaimer\x20</a></li>\n\t\x20\x20");
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (91%), Allied Telesyn embedded (89%), Linux (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (89%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   104.60 ms 45.15.165.51

Nmap scan report for 45.15.165.52
Host is up (0.24s latency).
Not shown: 990 closed tcp ports (reset)
PORT      STATE    SERVICE       VERSION
25/tcp    filtered smtp
80/tcp    open     tcpwrapped
|_http-title: 500 Internal Server Error
|_http-server-header: <empty>
2605/tcp  filtered bgpd
5009/tcp  filtered airport-admin
5431/tcp  filtered park-agent
7106/tcp  filtered unknown
8087/tcp  filtered simplifymedia
16001/tcp filtered fmsascon
16018/tcp filtered unknown
16113/tcp filtered unknown
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (91%), Allied Telesyn embedded (89%), Linux (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (89%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   248.79 ms 45.15.165.52

Nmap scan report for 45.15.165.53
Host is up (0.24s latency).
Not shown: 991 closed tcp ports (reset)
PORT      STATE    SERVICE    VERSION
25/tcp    filtered smtp
80/tcp    open     http
| fingerprint-strings: 
|   GetRequest: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:40 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|     <li><a href="disclaimer.html"> Disclaimer </a></li>
|   HTTPOptions: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:43 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|_    <li><a href="disclaimer.html"> Disclaimer </a></li>
|_http-server-header: <empty>
|_http-title: 500 Internal Server Error
1030/tcp  filtered iad1
1085/tcp  filtered webobjects
2393/tcp  filtered ms-olap1
5431/tcp  filtered park-agent
5903/tcp  filtered vnc-3
9876/tcp  filtered sd
14000/tcp filtered scotty-ft
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port80-TCP:V=7.93%I=7%D=2/23%Time=63F855A9%P=x86_64-pc-linux-gnu%r(GetR
SF:equest,840,"HTTP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x20202
SF:3\x2006:15:40\x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIG
SF:IN\r\nX-XSS-Protection:\x201;\x20mode=block\r\nX-Content-Type-Options:\
SF:x20nosniff\r\nContent-Length:\x201869\r\nConnection:\x20close\r\nConten
SF:t-Type:\x20text/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PU
SF:BLIC\x20\"-//W3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http:
SF://www\.w3\.org/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmln
SF:s=\"http://www\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Co
SF:ntent-Type\"\x20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>G
SF:iftcomputer\.vip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/cs
SF:s\"\x20href=\"images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<
SF:body>\n<div\x20id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20hr
SF:ef=\"#\">Giftcomputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n
SF:\t<div\x20id=\"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20h
SF:ref=\"index\.html\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"priva
SF:cy\.html\">\x20Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\
SF:.html\">\x20Disclaimer\x20</a></li>\n\t\x20\x20")%r(HTTPOptions,840,"HT
SF:TP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x202023\x2006:15:43\
SF:x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIGIN\r\nX-XSS-Pr
SF:otection:\x201;\x20mode=block\r\nX-Content-Type-Options:\x20nosniff\r\n
SF:Content-Length:\x201869\r\nConnection:\x20close\r\nContent-Type:\x20tex
SF:t/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PUBLIC\x20\"-//W
SF:3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http://www\.w3\.org
SF:/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmlns=\"http://www
SF:\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Content-Type\"\x
SF:20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>Giftcomputer\.v
SF:ip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/css\"\x20href=\"
SF:images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<body>\n<div\x2
SF:0id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20href=\"#\">Giftc
SF:omputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n\t<div\x20id=\
SF:"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20href=\"index\.h
SF:tml\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"privacy\.html\">\x2
SF:0Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\.html\">\x20Di
SF:sclaimer\x20</a></li>\n\t\x20\x20");
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (99%), Oracle Virtualbox (97%), Allied Telesyn embedded (90%), Bay Networks embedded (90%), Linux (89%), Sling embedded (89%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:alliedtelesyn:at-9006 cpe:/h:baynetworks:baystack_450 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (99%), Oracle Virtualbox (97%), Allied Telesyn AT-9006SX/SC switch (90%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (89%), Slingmedia Slingbox AV TV over IP gateway (89%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   238.52 ms 45.15.165.53

Nmap scan report for 45.15.165.54
Host is up (0.087s latency).
Not shown: 989 closed tcp ports (reset)
PORT      STATE    SERVICE     VERSION
25/tcp    filtered smtp
80/tcp    open     http
|_http-title: 500 Internal Server Error
|_http-server-header: <empty>
| fingerprint-strings: 
|   GetRequest: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:40 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|     <li><a href="disclaimer.html"> Disclaimer </a></li>
|   HTTPOptions: 
|     HTTP/1.1 200 OK
|     Date: Fri, 24 Feb 2023 06:15:43 GMT
|     Server: 
|     X-Frame-Options: SAMEORIGIN
|     X-XSS-Protection: 1; mode=block
|     X-Content-Type-Options: nosniff
|     Content-Length: 1869
|     Connection: close
|     Content-Type: text/html; charset=UTF-8
|     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
|     <html xmlns="http://www.w3.org/1999/xhtml">
|     <head>
|     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
|     <title>Giftcomputer.vip</title>
|     <link rel="stylesheet" type="text/css" href="images/style.css" media="screen" />
|     </head>
|     <body>
|     <div id="header">
|     <div id="logo">
|     <h1><a href="#">Giftcomputer.vip</a></h1>
|     </div>
|     <div id="menu">
|     <ul>
|     class="active"><a href="index.html"> Home </a></li>
|     <li><a href="privacy.html"> Privacy </a></li>
|_    <li><a href="disclaimer.html"> Disclaimer </a></li>
1213/tcp  filtered mpc-lifenet
4129/tcp  filtered nuauth
5431/tcp  filtered park-agent
5910/tcp  filtered cm
5962/tcp  filtered unknown
6001/tcp  filtered X11:1
6699/tcp  filtered napster
7496/tcp  filtered unknown
32782/tcp filtered unknown
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port80-TCP:V=7.93%I=7%D=2/23%Time=63F855A9%P=x86_64-pc-linux-gnu%r(GetR
SF:equest,840,"HTTP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x20202
SF:3\x2006:15:40\x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIG
SF:IN\r\nX-XSS-Protection:\x201;\x20mode=block\r\nX-Content-Type-Options:\
SF:x20nosniff\r\nContent-Length:\x201869\r\nConnection:\x20close\r\nConten
SF:t-Type:\x20text/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PU
SF:BLIC\x20\"-//W3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http:
SF://www\.w3\.org/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmln
SF:s=\"http://www\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Co
SF:ntent-Type\"\x20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>G
SF:iftcomputer\.vip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/cs
SF:s\"\x20href=\"images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<
SF:body>\n<div\x20id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20hr
SF:ef=\"#\">Giftcomputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n
SF:\t<div\x20id=\"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20h
SF:ref=\"index\.html\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"priva
SF:cy\.html\">\x20Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\
SF:.html\">\x20Disclaimer\x20</a></li>\n\t\x20\x20")%r(HTTPOptions,840,"HT
SF:TP/1\.1\x20200\x20OK\r\nDate:\x20Fri,\x2024\x20Feb\x202023\x2006:15:43\
SF:x20GMT\r\nServer:\x20\x20\r\nX-Frame-Options:\x20SAMEORIGIN\r\nX-XSS-Pr
SF:otection:\x201;\x20mode=block\r\nX-Content-Type-Options:\x20nosniff\r\n
SF:Content-Length:\x201869\r\nConnection:\x20close\r\nContent-Type:\x20tex
SF:t/html;\x20charset=UTF-8\r\n\r\n\n<!DOCTYPE\x20html\x20PUBLIC\x20\"-//W
SF:3C//DTD\x20XHTML\x201\.0\x20Transitional//EN\"\x20\"http://www\.w3\.org
SF:/TR/xhtml1/DTD/xhtml1-transitional\.dtd\">\n<html\x20xmlns=\"http://www
SF:\.w3\.org/1999/xhtml\">\n<head>\n<meta\x20http-equiv=\"Content-Type\"\x
SF:20content=\"text/html;\x20charset=utf-8\"\x20/>\n<title>Giftcomputer\.v
SF:ip</title>\n<link\x20rel=\"stylesheet\"\x20type=\"text/css\"\x20href=\"
SF:images/style\.css\"\x20media=\"screen\"\x20/>\n</head>\n<body>\n<div\x2
SF:0id=\"header\">\n\t<div\x20id=\"logo\">\n\t\t<h1><a\x20href=\"#\">Giftc
SF:omputer\.vip</a></h1>\n\t\t\x20\n\x20\x20</div>\n\t\x20\n\t<div\x20id=\
SF:"menu\">\n\t\t<ul>\n\t\t\t<li\x20class=\"active\"><a\x20href=\"index\.h
SF:tml\">\x20Home\x20</a></li>\n\t\t\t<li><a\x20href=\"privacy\.html\">\x2
SF:0Privacy\x20</a></li>\n\t\t\t<li><a\x20href=\"disclaimer\.html\">\x20Di
SF:sclaimer\x20</a></li>\n\t\x20\x20");
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (96%), Bay Networks embedded (91%), Allied Telesyn embedded (89%), Linux (89%), Sling embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (89%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 8888/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   204.45 ms 45.15.165.54

Nmap scan report for 45.15.165.55
Host is up (0.00031s latency).
All 1000 scanned ports on 45.15.165.55 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-7 are the same as for 45.15.165.60
8   ... 30

Nmap scan report for 45.15.165.56
Host is up (0.00029s latency).
All 1000 scanned ports on 45.15.165.56 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-9 are the same as for 45.15.165.60
10  ... 30

Nmap scan report for 45.15.165.57
Host is up (0.096s latency).
All 1000 scanned ports on 45.15.165.57 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 10 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-9 are the same as for 45.15.165.60
10  95.96 ms 45.15.165.57

Nmap scan report for 45.15.165.58
Host is up (0.12s latency).
Not shown: 993 filtered tcp ports (no-response)
PORT     STATE  SERVICE       VERSION
20/tcp   closed ftp-data
21/tcp   closed ftp
22/tcp   open   ssh           OpenSSH 8.9p1 Ubuntu 3ubuntu0.1 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   256 41ded681a656ce410787ba85a0794944 (ECDSA)
|_  256 c503354738a19c774961b2dc3b027240 (ED25519)
80/tcp   open   http          nginx
|_http-title: 404 Not Found
443/tcp  open   ssl/http      nginx
| tls-alpn: 
|   h2
|   http/1.1
|   http/1.0
|_  http/0.9
| ssl-cert: Subject: commonName=CloudFlare Origin Certificate/organizationName=CloudFlare, Inc.
| Subject Alternative Name: DNS:*.maolog.com, DNS:maolog.com
| Not valid before: 2022-09-09T02:37:00
|_Not valid after:  2037-09-05T02:37:00
|_ssl-date: TLS randomness does not represent time
|_http-title: Did not follow redirect to https://45.15.165.58/
888/tcp  open   http          nginx
|_http-title: 404 Not Found
8090/tcp open   opsmessaging?
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (91%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

TRACEROUTE (using port 21/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 45.15.164.142
2   141.78 ms 45.15.165.58

Nmap scan report for 45.15.165.59
Host is up (0.0024s latency).
All 1000 scanned ports on 45.15.165.59 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-10 are the same as for 45.15.165.60
11  ... 30

Nmap scan report for 45.15.165.60
Host is up (0.0023s latency).
All 1000 scanned ports on 45.15.165.60 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT        ADDRESS
-   Hops 1-4 are the same as for 45.15.164.142
5   42.20 ms   4.68.38.173
6   2408.20 ms 4.69.219.41
7   202.87 ms  4.78.193.6
8   88.58 ms   185.205.13.50
9   200.12 ms  23.147.224.113
10  72.56 ms   23.147.224.50
11  ... 30

Nmap scan report for 45.15.165.61
Host is up (0.0023s latency).
All 1000 scanned ports on 45.15.165.61 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-10 are the same as for 45.15.165.60
11  ... 30

Nmap scan report for 45.15.165.62
Host is up (0.0022s latency).
All 1000 scanned ports on 45.15.165.62 are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-10 are the same as for 45.15.165.60
11  ... 30
