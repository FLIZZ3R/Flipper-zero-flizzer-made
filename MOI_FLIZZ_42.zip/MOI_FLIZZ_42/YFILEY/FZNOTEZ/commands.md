sudo ufw-
status verbose-
default allow/deny outgoing/incoming
allow/deny incoming/outgoing
allow in on <device> from <ip>
dissable 
enable
____
ufw rules= vim /etc/ufw/u
-ip a=show ip/mac
