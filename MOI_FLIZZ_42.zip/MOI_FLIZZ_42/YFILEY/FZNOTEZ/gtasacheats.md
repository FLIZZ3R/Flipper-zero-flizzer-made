San Andreas PS4 / PS5 Cheats
Cheat 	Code
Health, Armor, and Money ($250,000) 	R1, R2, L1, X, LEFT, DOWN, RIGHT, UP, LEFT, DOWN, RIGHT, UP
Infinite Ammo	L1, R1, SQUARE, R1, LEFT, R2, R1, LEFT, SQUARE, DOWN, L1, L1
(Almost) Infinite Health	Down, X, Right, Left, Right, R1, Right, Down, Up, Triangle
Weapons 1 (Bat, Pistol, Shotgun, Mini SMG, AK 47, Rocket Launcher, Molotov Cocktail, Spray Can, Brass Knuckles.)	R1, R2, L1, R2, LEFT, DOWN, RIGHT, UP, LEFT, DOWN, RIGHT, UP
Weapons 2 (Knife, Pistol, Sawed-Off Shotgun, Tec 9, Sniper Rifle, Flamethrower, Grenades, Fire Extinguisher.)	R1, R2, L1, R2, LEFT, DOWN, RIGHT, UP, LEFT, DOWN, DOWN, LEFT
Weapons 3 (Chainsaw, Silenced Pistol, Combat Shotgun, M4, Bazooka, Plastic Explosive)	R1, R2, L1, R2, LEFT, DOWN, RIGHT, UP, LEFT, DOWN, DOWN, DOWN
Wanted Level Down	R1, R1, CIRCLE, R2, UP, DOWN, UP, DOWN, UP, DOWN
Wanted Level Up	R1, R1, CIRCLE, R2, LEFT, RIGHT, LEFT, RIGHT, LEFT, RIGHT
Lock Wanted Level	Circle, Right, Circle, Right, Left, Square, Triangle, Up
Maximum Wanted Level	CIRCLE, RIGHT, CIRCLE, RIGHT, LEFT, SQUARE, X, DOWN
Pedestrian Riot	DOWN, LEFT, UP, LEFT, X, R2, R1, L2, L
Chaos Mode	L2, RIGHT, L1, TRIANGLE, RIGHT, RIGHT, R1, L1, RIGHT, L1, L1, L
Bounty on Your Head	DOWN, UP, UP, UP, X, R2, R1, L2, L
Pedestrians Attack (With Guns)	X, L1, UP, SQUARE, DOWN, X, L2, TRIANGLE, DOWN, R1, L1, L1
Pedestrians Have Weapons	R2, R1, X, TRIANGLE, X, TRIANGLE, UP, DOWN
All Pedestrians Are Elvis	L1, CIRCLE, TRIANGLE, L1, L1, SQUARE, L2, UP, DOWN, LEFT
Beach Party Mode	UP, UP, DOWN, DOWN, SQUARE, CIRCLE, L1, R1, TRIANGLE, DOWN
Triad Theme	X, X, DOWN, R2, L2, CIRCLE, R1, CIRCLE, SQUARE
Funhouse Theme	TRIANGLE, TRIANGLE, L1, SQUARE, SQUARE, CIRCLE, SQUARE, DOWN, CIRCLE
Rural Theme	L1, L1, R1, R1, L2, L1, R2, DOWN, LEFT, UP
Kinky Theme	SQUARE, RIGHT, SQUARE, SQUARE, L2, X, TRIANGLE, X, TRIANGLE
Mega Jump	UP, UP, TRIANGLE, TRIANGLE, UP, UP, LEFT, RIGHT, SQUARE, R2, R2
Super Punch	UP, LEFT, X, TRIANGLE, R1, SQUARE, SQUARE, SQUARE, L2
Spawn Rhino Tank	CIRCLE, CIRCLE, L1, CIRCLE, CIRCLE, CIRCLE, L1, L2, R1, TRIANGLE, CIRCLE, TRIANGLE
Spawn Jetpack	L1, L2, R1, R2, UP, DOWN, LEFT, RIGHT, L1, L2, R1, R2, UP, DOWN, LEFT, RIGHT
Spawn Hydra	TRIANGLE, TRIANGLE, SQUARE, CIRCLE, X, L1, L1, DOWN, UP
Spawn Hunter	CIRCLE, X, L1, CIRCLE, CIRCLE, L1, CIRCLE, R1 R2, L2, L1, L1
Spawn Stunt Plane	CIRCLE, UP, L1, L2, DOWN, R1, L1, L1, LEFT, LEFT, X, TRIANGLE
Spawn Bloodring Banger	DOWN, R1, CIRCLE, L2, L2, X, R1, L1, LEFT, LEFT
Spawn Vortex Hovercraft	TRIANGLE, TRIANGLE, SQUARE, CIRCLE, X, L1, L2, DOWN, DOWN
Spawn Parachute	LEFT, RIGHT, L1, L2, R1, R2, R2, UP, DOWN, RIGHT, L1
Spawn Monster	RIGHT, UP, R1, R1, R1, DOWN, TRIANGLE, TRIANGLE, X, CIRCLE, L1, L1
Spawn Hotring Racer #1	R1, CIRCLE, R2, RIGHT, L1, L2, X, X, SQUARE, R1
Spawn Hotring Racer #2	R2, L1, CIRCLE, RIGHT, L1, R1, RIGHT, UP, CIRCLE, R2
Spawn Romero	DOWN, R2, DOWN, R1, L2, LEFT, R1, L1, LEFT, RIGHT
Spawn Stretch	R2, UP, L2, LEFT, LEFT, R1, L1, CIRCLE, RIGHT
Spawn Trashmaster	CIRCLE, R1, CIRCLE, R1, LEFT, LEFT, R1, L1, CIRCLE, RIGHT
Spawn Caddy	CIRCLE, L1, UP, R1, L2, X, R1, L1, CIRCLE, X
Spawn Quad	LEFT, LEFT, DOWN, DOWN, UP, UP, SQUARE, CIRCLE, TRIANGLE, R1, R2
Spawn Tanker Truck	R1, UP, LEFT, RIGHT, R2, UP, RIGHT, SQUARE, RIGHT, L2, L1, L1
Spawn Dozer	R2, L1, L1, RIGHT, RIGHT, UP, UP, X, L1, LEFT
Spawn Rancher	UP, RIGHT, RIGHT, L1, RIGHT, UP, X, L2
Max Muscle	TRIANGLE, UP, UP, LEFT, RIGHT, SQUARE, CIRCLE, LEFT
Max Fat	TRIANGLE, UP, UP, LEFT, RIGHT, SQUARE, CIRCLE, DOWN
Minimum Muscle and Fat	TRIANGLE, UP, UP, LEFT, RIGHT, SQUARE, CIRCLE, RIGHT
Infinite Lung Capacity	DOWN, LEFT, L1, DOWN, DOWN, R2, DOWN, L2, DOWN
Never Get Hungry	SQUARE, L2, RB, TRIANGLE, UP, SQUARE, L2, UP, X
Maximum Respect	L1, R1, TRIANGLE, DOWN, R2, X, L1, UP, L2, L2, L1, L1
Maximum Sex Appeal	CIRCLE, TRIANGLE, TRIANGLE, UP, CIRCLE, R1, L2, UP, TRIANGLE, L1, L1, L1
Hitman Level For All Weapons	DOWN, SQUARE, X, LEFT, R1, R2, LEFT, DOWN, DOWN, L1, L1, L1
Gang Members Mode	LEFT, RIGHT, RIGHT, RIGHT, LEFT, X, DOWN, UP, SQUARE, RIGHT, DOWN
Gang Control	L2, UP, R1, R1, LEFT, R1, R1, R2, RIGHT, DOWN
Recruit Anyone (Pistol)	DOWN, SQUARE, UP, R2, R2, UP, RIGHT, RIGHT, UP
Recruit Anyone (Rocket Launcher)	R2, R2, R2, X, L2, L1, R1, L2, DOWN, X
Always Midnight	SQUARE, L1, R1, RIGHT, X, UP, L1, LEFT, LEFT
Always 21:00	LEFT, LEFT, L2, R1, RIGHT, SQUARE, SQUARE, L1, L2, X
Slow Motion	TRIANGLE, UP, RIGHT, DOWN, SQUARE, R2, R1
Fast Motion	TRIANGLE, UP, RIGHT, DOWN, L2, L1, SQUARE
Faster Clock	CIRCLE, CIRCLE, L1, SQUARE, L1, SQUARE, SQUARE, SQUARE, L1, TRIANGLE, CIRCLE, TRIANGLE
Cloudy Weather	L2, DOWN, DOWN, LEFT, SQUARE, LEFT, R2, SQUARE, X, R1, L1, L1
Foggy Weather	R2, X, L1, L1, L2, L2, L2, X
Stormy Weather	R2, X, L1, L1, L2, L2, L2, CIRCLE
Sunny Weather	R2, X, L1, L1, L2, L2, L2, SQUARE
Very Sunny Weather	R2, X, L1, L1, L2, L2, L2, DOWN
Sandstorm	UP, DOWN, L1, L1, L2, L2, L1, L2, R1, R2
Free Aim While Driving	UP, UP, SQUARE, L2, RIGHT, X, R1, DOWN, R2, CIRCLE
Blow Up All Cars	R2, L2, R1, L1, L2, R2, SQUARE, TRIANGLE, CIRCLE, TRIANGLE, L2, L1
Traffic Lights Stay Green	RIGHT, R1, UP, L2, L2, LEFT, R1, L1, R1, R1
Aggressive Traffic	R2, CIRCLE, R1, L2, LEFT, R1, L1, R2, L2
Increase Car Speed	RIGHT, R1, UP, L2, L2, LEFT, R1, L1, R1, R1
All Cars Have Nitrous	LEFT, TRIANGLE, R1, L1, UP, SQUARE, TRIANGLE, DOWN, CIRCLE, L2, L1, L1
Flying Cars	SQUARE, DOWN, L2, UP, L1, CIRCLE, UP, X, LEFT
Flying Boats	R2, CIRCLE, UP, L1, RIGHT, R1, RIGHT, UP, SQUARE, TRIANGLE
Drive on Water	RIGHT, R2, CIRCLE, R1, L2, SQUARE, R1, R2
Perfect Vehicle Handling	TRIANGLE, R1, R1, LEFT, R1, L1, R2, L1
Super Bunny Hop	TRIANGLE, SQUARE, CIRCLE, CIRCLE, SQUARE, CIRCLE, CIRCLE, L1, L2, L2, R1, R2
Invisible Cars	TRIANGLE, L1, TRIANGLE, R2, SQUARE, L1, L1
Moon Car Gravity	SQUARE, R2, DOWN, DOWN, LEFT, DOWN, LEFT, LEFT L2, X
Reduced Traffic	X, DOWN, UP, R2, DOWN, TRIANGLE, L1, TRIANGLE, LEFT
Pink Cars	CIRCLE, L1, DOWN, L2, LEFT, X, R1, L1, RIGHT, CIRCLE
Black Cars	CIRCLE, L2, UP, R1, LEFT, X, R1, L1, LEFT, CIRCLE
Sports Cars	UP, L1, R1, UP, RIGHT, UP, X, L2, X, L1
Junk Cars	L2, RIGHT, L1, UP, X, L1, L2, R2, R1, L1, L1, L1 