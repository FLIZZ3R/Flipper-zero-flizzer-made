--------
KALI ANON
-----t---
-PROXYCHAINS	
--locate proxychains
---sudo vi /etc/proxychains.conf
-dynamic
___________
try diz
-proxychains nmap -sT -p 80,443 <stat ip>
___n_______________
john hammond live
dirtycow???e
-understand python and symbols
-linux
-scripting in general
-dont give up moving quickly
-bugbounty: working aginst real life application/corps pentesting
-capture the flag: you know there is a way in pentesting
-looking for persistance in bugs in net 
-CTF!!!
_______________
-SECURITY PLUS
-SMASH THE STACKT 
-LEARN TO WRITE OR AT LEAST TWEEK SCRIPTS 

