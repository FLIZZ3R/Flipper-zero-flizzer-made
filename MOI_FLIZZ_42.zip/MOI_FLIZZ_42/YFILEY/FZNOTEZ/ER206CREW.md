NETWORKING
____________
TCP-
UDP-
IP ADDRESSES-
 IPV4        inet 127.0.0.1  netmask 255.0.0.0
IPV6>
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 9951  bytes 658934 (658.9 KB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 9951  bytes 6589 (658.9 KB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
YOUR IP ADDY RENTED FROM ISP EACH NETWORK  MACHINE HAS. IPV4 IS PUBLIC ADDY
RENTED FROM ISP.
________________________
MAC ADDRESSES-
PHYSICAL MACHINE ADDRESS TELLS WHICH MACHINE IS WHICH
COMMON PORTS AND PROTOCALL-
