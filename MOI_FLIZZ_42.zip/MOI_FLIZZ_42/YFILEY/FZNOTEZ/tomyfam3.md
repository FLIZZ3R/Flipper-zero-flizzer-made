

ap scan report for 174-21-0-9.tukw.qwest.net (174.21.0.9)
Host is up (0.14s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1
|_    Connection: close
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E956C3%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(HTTPOptions,
SF:1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(FourOhFourRequest,1F,
SF:"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n");
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (87%), Samsung CLP-315W printer (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (86%), Dell 1815dn printer (86%), VxWorks (86%), IBM OS/2 Warp 2.0 (86%), Xerox WorkCentre 4150 printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 4567/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   242.10 ms 174-21-0-9.tukw.qwest.net (174.21.0.9)

Nmap scan report for 174-21-0-10.tukw.qwest.net (174.21.0.10)
Host is up (0.34s latency).
Not shown: 997 closed tcp ports (reset)
PORT     STATE    SERVICE VERSION
25/tcp   filtered smtp
443/tcp  open     https?
4567/tcp open     tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1 401 Authorization Required
|_    Content-Length: 0
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E956C3%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,3A,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-L
SF:ength:\x200\r\n\r\n")%r(HTTPOptions,3A,"HTTP/1\.1\x20401\x20Authorizati
SF:on\x20Required\r\nContent-Length:\x200\r\n\r\n")%r(FourOhFourRequest,3A
SF:,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-Length:\x200
SF:\r\n\r\n");
Aggressive OS guesses: Sony Ericsson W705 or W715 Walkman mobile phone (90%), Linux 2.0.33 (90%), Cisco Catalyst 1900 switch (89%), QEMU user mode network gateway (88%), GNU Hurd 0.3 (88%), Sony PlayStation 3 game console (87%), Nokia 3600i mobile phone (86%), StarDot NetCam SC webcam (Linux 2.0.39) (86%), Apple Time Capsule NAS device (85%), EasyPath PON switch (85%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 143/tcp)
HOP RTT        ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   1273.92 ms 174-21-0-10.tukw.qwest.net (174.21.0.10)

Nmap scan report for 174-21-0-11.tukw.qwest.net (174.21.0.11)
Host is up (0.25s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: Cisco Catalyst 1900 switch (91%), Nokia 3600i mobile phone (90%), Cisco ATA 188 VoIP adapter (89%), QEMU user mode network gateway (88%), Apple Time Capsule NAS device (87%), Sony Ericsson W705 or W715 Walkman mobile phone (87%), Linux 2.0.33 (86%), GNU Hurd 0.3 (85%), ADSL router: Huawei MT800u-T; or ZyXEL Prestige 623ME-T1, 643, 662HW-61, 782, or 2602R-61 (85%), Huawei Echolife HG520-series ADSL modem (85%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 4567/tcp)
HOP RTT        ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   1401.98 ms 174-21-0-11.tukw.qwest.net (174.21.0.11)

Nmap scan report for 174-21-0-12.tukw.qwest.net (174.21.0.12)
Host is up (0.15s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE  VERSION
8443/tcp open  ssl/http ASUS WRT http admin
|_ssl-date: TLS randomness does not represent time
|_http-server-header: httpd/2.0
| ssl-cert: Subject: commonName=192.168.1.1/organizationName=ASUSWRT-Merlin/countryName=US
| Subject Alternative Name: IP Address:192.168.1.1, DNS:192.168.1.1, DNS:router.asus.com, DNS:RT-AC87U-BC68, DNS:AD675DE70D686CF40769DA3C2992A14E6.asuscomm.com
| Not valid before: 2018-05-05T05:05:26
|_Not valid after:  2028-05-05T05:05:26
|_http-title: Site doesn't have a title (text/html).
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge|general purpose|switch|media device
Running (JUST GUESSING): Oracle Virtualbox (97%), QEMU (97%), Bay Networks embedded (91%), Allied Telesyn embedded (90%), Linux (88%), Sling embedded (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: Oracle Virtualbox (97%), QEMU user mode network gateway (97%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (90%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: CPE: cpe:/o:asus:wrt_firmware

TRACEROUTE (using port 8443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   383.19 ms 174-21-0-12.tukw.qwest.net (174.21.0.12)

Nmap scan report for 174-21-0-13.tukw.qwest.net (174.21.0.13)
Host is up (0.00077s latency).
All 1000 scanned ports on 174-21-0-13.tukw.qwest.net (174.21.0.13) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   339.78 ms 174-21-0-14.tukw.qwest.net (174.21.0.14)

Nmap scan report for 174-21-0-15.tukw.qwest.net (174.21.0.15)
Host is up (0.072s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (92%), Cisco SG 500 switch (90%), Sitecom WL-174 wireless ADSL router or ZyXEL B-3000 WAP (90%), Cisco 5300 router (IOS 12.1) (90%), ZyXEL Prestige 660R ADSL router (90%), Oracle Virtualbox (89%), Samsung CLP-310N or CLX-3175RW, or Xerox Phaser 6110 printer (89%), Samsung CLX-3160FN printer (89%), Cisco IP Phone 7912-series (88%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (88%)
No exact OS matches for host (test conditions non-ideal).

TRACEROUTE (using port 4567/tcp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-16.tukw.qwest.net (174.21.0.16)
Host is up (0.22s latency).
All 1000 scanned ports on 174-21-0-16.tukw.qwest.net (174.21.0.16) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   230.87 ms 174-21-0-16.tukw.qwest.net (174.21.0.16)

Nmap scan report for 174-21-0-17.tukw.qwest.net (174.21.0.17)
Host is up (0.25s latency).
All 1000 scanned ports on 174-21-0-17.tukw.qwest.net (174.21.0.17) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   370.24 ms 174-21-0-17.tukw.qwest.net (174.21.0.17)

Nmap scan report for 174-21-0-18.tukw.qwest.net (174.21.0.18)
Host is up (0.23s latency).
All 1000 scanned ports on 174-21-0-18.tukw.qwest.net (174.21.0.18) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops
TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-25.tukw.qwest.net (174.21.0.25)
Host is up (0.14s latency).
Not shown: 998 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
5101/tcp open  admdog?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (92%), ZyXEL Prestige 660R ADSL router (90%), Sitecom WL-174 wireless ADSL router or ZyXEL B-3000 WAP (90%), Oracle Virtualbox (90%), Samsung CLP-310N or CLX-3175RW, or Xerox Phaser 6110 printer (89%), Cisco IP Phone 7912-series (89%), Samsung CLX-3160FN printer (89%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), GNU Hurd 0.3 (88%), ADSL router: Huawei MT800u-T; or ZyXEL Prestige 623ME-T1, 643, 662HW-61, 782, or 2602R-61 (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 5101/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   304.10 ms 174-21-0-25.tukw.qwest.net (174.21.0.25)

Nmap scan report for 174-21-0-26.tukw.qwest.net (174.21.0.26)
Host is up (0.00045s latency).
All 1000 scanned ports on 174-21-0-26.tukw.qwest.net (174.21.0.26) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-27.tukw.qwest.net (174.21.0.27)
Host is up (0.21s latency).
All 1000 scanned ports on 174-21-0-27.tukw.qwest.net (174.21.0.27) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   287.78 ms 174-21-0-27.tukw.qwest.net (174.21.0.27)


TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-34.tukw.qwest.net (174.21.0.34)
Host is up (0.060s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (92%), Cisco SG 500 switch (90%), Sitecom WL-174 wireless ADSL router or ZyXEL B-3000 WAP (90%), Cisco 5300 router (IOS 12.1) (90%), ZyXEL Prestige 660R ADSL router (90%), Oracle Virtualbox (89%), Samsung CLP-310N or CLX-3175RW, or Xerox Phaser 6110 printer (89%), Samsung CLX-3160FN printer (89%), Cisco IP Phone 7912-series (88%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (88%)
No exact OS matches for host (test conditions non-ideal).

TRACEROUTE (using port 4567/tcp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-35.tukw.qwest.net (174.21.0.35)
Host is up (0.00056s latency).
All 1000 scanned ports on 174-21-0-35.tukw.qwest.net (174.21.0.35) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-36.tukw.qwest.net (174.21.0.36)
Host is up (0.00057s latency).
All 1000 scanned ports on 174-21-0-36.tukw.qwest.net (174.21.0.36) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-42.tukw.qwest.net (174.21.0.42)
Host is up (0.063s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE    VERSION
4567/tcp open  tcpwrapped
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (94%), Linux 2.0.33 (93%), Oracle Virtualbox (92%), Samsung CLP-310N or CLX-3175RW, or Xerox Phaser 6110 printer (91%), Huawei Echolife HG520-series ADSL modem (91%), TP-LINK TD-W8951ND wireless ADSL modem (91%), ZyXEL Prestige 200 ISDN router (91%), ZyXEL ZyNOS 3.40 (91%), ZyXEL Prestige 2602R-D1A ADSL router (91%), ADSL router: Huawei MT800u-T; or ZyXEL Prestige 623ME-T1, 643, 662HW-61, 782, or 2602R-61 (91%)
No exact OS matches for host (test conditions non-ideal).

TRACEROUTE (using port 4567/tcp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-43.tukw.qwest.net (174.21.0.43)
Host is up (0.15s latency).
Not shown: 998 filtered tcp ports (no-response)
PORT     STATE SERVICE  VERSION
443/tcp  open  ssl/http nginx
| ssl-cert: Subject: organizationName=Technicolor/stateOrProvinceName=Antwerp/countryName=BE
| Not valid before: 2019-12-10T02:17:22
|_Not valid after:  2029-12-07T02:17:22
|_ssl-date: TLS randomness does not represent time
| tls-alpn:
|_  http/1.1
|_http-title: 403 Forbidden
4567/tcp open  http     Thomson DSL router TR-069
|_http-title: Site doesn't have a title.
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (88%), Samsung CLP-315W printer (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (86%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), Dell 1815dn printer (86%), VxWorks (86%), IBM OS/2 Warp 2.0 (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Device: broadband router

TRACEROUTE (using port 443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   323.42 ms 174-21-0-43.tukw.qwest.net (174.21.0.43)

Nmap scan report for 174-21-0-44.tukw.qwest.net (174.21.0.44)
Host is up (0.16s latency).
All 1000 scanned ports on 174-21-0-44.tukw.qwest.net (174.21.0.44) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   283.71 ms 174-21-0-44.tukw.qwest.net (174.21.0.44)

Nmap scan report for 174-21-0-45.tukw.qwest.net (174.21.0.45)
Host is up (0.25s latency).
All 1000 scanned ports on 174-21-0-45.tukw.qwest.net (174.21.0.45) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   269.76 ms 174-21-0-45.tukw.qwest.net (174.21.0.45)

Nmap scan report for 174-21-0-46.tukw.qwest.net (174.21.0.46)
Host is up (0.00042s latency).
All 1000 scanned ports on 174-21-0-46.tukw.qwest.net (174.21.0.46) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-47.tukw.qwest.net (174.21.0.47)
Host is up (0.00021s latency).
All 1000 scanned ports on 174-21-0-47.tukw.qwest.net (174.21.0.47) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-48.tukw.qwest.net (174.21.0.48)
Host is up (0.16s latency).
All 1000 scanned ports on 174-21-0-48.tukw.qwest.net (174.21.0.48) are in ignored states.


RACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   83.05 ms 174-21-0-53.tukw.qwest.net (174.21.0.53)

Nmap scan report for 174-21-0-54.tukw.qwest.net (174.21.0.54)
Host is up (0.16s latency).
Not shown: 994 closed tcp ports (reset)
PORT     STATE    SERVICE  VERSION
23/tcp   filtered telnet
25/tcp   filtered smtp
80/tcp   filtered http
443/tcp  filtered https
4567/tcp open     tram?
5550/tcp filtered sdadmind
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 143/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   305.77 ms 174-21-0-54.tukw.qwest.net (174.21.0.54)

Nmap scan report for 174-21-0-55.tukw.qwest.net (174.21.0.55)
Host is up (0.00020s latency).
All 1000 scanned ports on 174-21-0-55.tukw.qwest.net (174.21.0.55) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-56.tukw.qwest.net (174.21.0.56)
Host is up (0.15s latency).
All 1000 scanned ports on 174-21-0-56.tukw.qwest.net (174.21.0.56) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   147.74 ms 174-21-0-56.tukw.qwest.net (174.21.0.56)

Nmap scan report for 174-21-0-57.tukw.qwest.net (174.21.0.57)
Host is up (0.00019s latency).
All 1000 scanned ports on 174-21-0-57.tukw.qwest.net (174.21.0.57) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-58.tukw.qwest.net (174.21.0.58)
Host is up (0.25s latency).
All 1000 scanned ports on 174-21-0-58.tukw.qwest.net (174.21.0.58) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   553.87 ms 174-21-0-58.tukw.qwest.net (174.21.0.58)

Nmap scan report for 174-21-0-59.tukw.qwest.net (174.21.0.59)
Host is up (0.15s latency).
Not shown: 998 closed tcp ports (reset)
PORT     STATE    SERVICE VERSION
25/tcp   filtered smtp
4567/tcp open     tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1 401 Authorization Required
|_    Content-Length: 0
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E956C3%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,3A,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-L
SF:ength:\x200\r\n\r\n")%r(HTTPOptions,3A,"HTTP/1\.1\x20401\x20Authorizati
SF:on\x20Required\r\nContent-Length:\x200\r\n\r\n")%r(FourOhFourRequest,3A
SF:,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-Length:\x200
SF:\r\n\r\n");
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 143/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   317.34 ms 174-21-0-59.tukw.qwest.net (174.21.0.59)

Nmap scan report for 174-21-0-60.tukw.qwest.net (174.21.0.60)
Host is up (0.14s latency).
Not shown: 998 closed tcp ports (reset)
PORT     STATE    SERVICE VERSION
25/tcp   filtered smtp
4567/tcp open     tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1 401 Authorization Required
|_    Content-Length: 0
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E956C3%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,3A,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-L
SF:ength:\x200\r\n\r\n")%r(HTTPOptions,3A,"HTTP/1\.1\x20401\x20Authorizati
SF:on\x20Required\r\nContent-Length:\x200\r\n\r\n")%r(FourOhFourRequest,3A
SF:,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-Length:\x200
SF:\r\n\r\n");
Device type: general purpose|bridge|switch|media device
Running (JUST GUESSING): QEMU (98%), Oracle Virtualbox (94%), Bay Networks embedded (90%), Sling embedded (88%), Allied Telesyn embedded (88%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/h:slingmedia:slingbox_av cpe:/h:alliedtelesyn:at-9006
Aggressive OS guesses: QEMU user mode network gateway (98%), Oracle Virtualbox (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (88%), Allied Telesyn AT-9006SX/SC switch (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 143/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   220.19 ms 174-21-0-60.tukw.qwest.net (174.21.0.60)

Nmap scan report for 174-21-0-61.tukw.qwest.net (174.21.0.61)
Host is up (0.24s latency).
All 1000 scanned ports on 174-21-0-61.tukw.qwest.net (174.21.0.61) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   265.15 ms 174-21-0-61.tukw.qwest.net (174.21.0.61)

Nmap scan report for 174-21-0-62.tukw.qwest.net (174.21.0.62)
Host is up (0.00021s latency).
All 1000 scanned ports on 174-21-0-62.tukw.qwest.net (174.21.0.62) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-63.tukw.qwest.net (174.21.0.63)
Host is up (0.13s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
5101/tcp open  admdog?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (97%), Oracle Virtualbox (95%), Bay Networks embedded (90%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 5101/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   110.00 ms 174-21-0-63.tukw.qwest.net (174.21.0.63)

Stats: 2:48:10 elapsed; 64 hosts completed (128 up), 64 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 13.77% done; ETC: 14:46 (1:10:01 remaining)
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
Nmap scan report for 174-21-0-64.tukw.qwest.net (174.21.0.64)
Host is up (0.11s latency).
All 1000 scanned ports on 174-21-0-64.tukw.qwest.net (174.21.0.64) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   188.75 ms 174-21-0-64.tukw.qwest.net (174.21.0.64)

Nmap scan report for 174-21-0-65.tukw.qwest.net (174.21.0.65)
Host is up (0.12s latency).
All 1000 scanned ports on 174-21-0-65.tukw.qwest.net (174.21.0.65) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   188.73 ms 174-21-0-65.tukw.qwest.net (174.21.0.65)

Nmap scan report for 174-21-0-66.tukw.qwest.net (174.21.0.66)
Host is up (0.00023s latency).
All 1000 scanned ports on 174-21-0-66.tukw.qwest.net (174.21.0.66) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-67.tukw.qwest.net (174.21.0.67)
Host is up (0.00025s latency).
All 1000 scanned ports on 174-21-0-67.tukw.qwest.net (174.21.0.67) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-68.tukw.qwest.net (174.21.0.68)
Host is up (0.095s latency).
All 1000 scanned ports on 174-21-0-68.tukw.qwest.net (174.21.0.68) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   98.36 ms 174-21-0-68.tukw.qwest.net (174.21.0.68)

Nmap scan report for 174-21-0-69.tukw.qwest.net (174.21.0.69)
Host is up (0.095s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1
|_    Connection: close
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E96B0D%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(HTTPOptions,
SF:1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(FourOhFourRequest,1F,
SF:"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n");
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (87%), Samsung CLP-315W printer (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (86%), Dell 1815dn printer (86%), VxWorks (86%), IBM OS/2 Warp 2.0 (86%), Xerox WorkCentre 4150 printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 4567/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   193.51 ms 174-21-0-69.tukw.qwest.net (174.21.0.69)

Nmap scan report for 174-21-0-70.tukw.qwest.net (174.21.0.70)
Host is up (0.00032s latency).
All 1000 scanned ports on 174-21-0-70.tukw.qwest.net (174.21.0.70) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-71.tukw.qwest.net (174.21.0.71)
Host is up (0.049s latency).
All 1000 scanned ports on 174-21-0-71.tukw.qwest.net (174.21.0.71) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   205.49 ms 174-21-0-71.tukw.qwest.net (174.21.0.71)

Nmap scan report for 174-21-0-72.tukw.qwest.net (174.21.0.72)
Host is up (0.00020s latency).
All 1000 scanned ports on 174-21-0-72.tukw.qwest.net (174.21.0.72) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-73.tukw.qwest.net (174.21.0.73)
Host is up (0.00020s latency).
All 1000 scanned ports on 174-21-0-73.tukw.qwest.net (174.21.0.73) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-74.tukw.qwest.net (174.21.0.74)
Host is up (0.094s latency).
All 1000 scanned ports on 174-21-0-74.tukw.qwest.net (174.21.0.74) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   90.30 ms 174-21-0-74.tukw.qwest.net (174.21.0.74)

Nmap scan report for 174-21-0-75.tukw.qwest.net (174.21.0.75)
Host is up (0.00011s latency).
All 1000 scanned ports on 174-21-0-75.tukw.qwest.net (174.21.0.75) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-76.tukw.qwest.net (174.21.0.76)

map scan report for 174-21-0-83.tukw.qwest.net (174.21.0.83)
Host is up (0.056s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (92%), ZyXEL Prestige 660R ADSL router (90%), Sitecom WL-174 wireless ADSL router or ZyXEL B-3000 WAP (90%), Oracle Virtualbox (90%), Samsung CLP-310N or CLX-3175RW, or Xerox Phaser 6110 printer (90%), Samsung CLX-3160FN printer (90%), Cisco IP Phone 7912-series (89%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), ADSL router: Huawei MT800u-T; or ZyXEL Prestige 623ME-T1, 643, 662HW-61, 782, or 2602R-61 (89%), GNU Hurd 0.3 (88%)
No exact OS matches for host (test conditions non-ideal).

TRACEROUTE (using port 4567/tcp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-84.tukw.qwest.net (174.21.0.84)
Host is up (0.00040s latency).
All 1000 scanned ports on 174-21-0-84.tukw.qwest.net (174.21.0.84) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-85.tukw.qwest.net (174.21.0.85)
Host is up (0.12s latency).
Not shown: 997 filtered tcp ports (no-response)
PORT     STATE SERVICE  VERSION
443/tcp  open  ssl/http nginx
| tls-alpn:
|_  http/1.1
| ssl-cert: Subject: organizationName=Technicolor/stateOrProvinceName=Antwerp/countryName=BE
| Not valid before: 2019-12-10T02:17:48
|_Not valid after:  2029-12-07T02:17:48
|_ssl-date: TLS randomness does not represent time
|_http-title: 400 The plain HTTP request was sent to HTTPS port
4567/tcp open  http     Thomson DSL router TR-069
|_http-title: Site doesn't have a title.
5101/tcp open  admdog?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Slingmedia Slingbox AV TV over IP gateway (87%), Allied Telesyn AT-9006SX/SC switch (86%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (86%), Samsung CLP-315W printer (86%), Dell 1815dn printer (86%), VxWorks (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Device: broadband router

TRACEROUTE (using port 443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   200.34 ms 174-21-0-85.tukw.qwest.net (174.21.0.85)

Nmap scan report for 174-21-0-86.tukw.qwest.net (174.21.0.86)
Host is up (0.74s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  http    Thomson DSL router TR-069
|_http-title: Site doesn't have a title.
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (97%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (89%), Slingmedia Slingbox AV TV over IP gateway (88%), Samsung CLP-315W printer (88%), Dell 1815dn printer (87%), VxWorks (87%), Allied Telesyn AT-9006SX/SC switch (87%), Samsung CLP-310N or CLX-3175RW, or Xerox Phaser 6110 printer (87%), Xerox WorkCentre 4150 printer (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Device: broadband router

TRACEROUTE (using port 4567/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   807.82 ms 174-21-0-86.tukw.qwest.net (174.21.0.86)

Nmap scan report for 174-21-0-87.tukw.qwest.net (174.21.0.87)
Host is up (0.14s latency).
All 1000 scanned ports on 174-21-0-87.tukw.qwest.net (174.21.0.87) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   102.39 ms 174-21-0-87.tukw.qwest.net (174.21.0.87)

Nmap scan report for 174-21-0-88.tukw.qwest.net (174.21.0.88)
Host is up (0.13s latency).
All 1000 scanned ports on 174-21-0-88.tukw.qwest.net (174.21.0.88) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   92.16 ms 174-21-0-88.tukw.qwest.net (174.21.0.88)

Nmap scan report for 174-21-0-89.tukw.qwest.net (174.21.0.89)
Host is up (0.14s latency).
All 1000 scanned ports on 174-21-0-89.tukw.qwest.net (174.21.0.89) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   104.98 ms 174-21-0-89.tukw.qwest.net (174.21.0.89)

Nmap scan report for 174-21-0-90.tukw.qwest.net (174.21.0.90)
Host is up (0.00040s latency).
All 1000 scanned ports on 174-21-0-90.tukw.qwest.net (174.21.0.90) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-91.tukw.qwest.net (174.21.0.91)
Host is up (0.00036s latency).
All 1000 scanned ports on 174-21-0-91.tukw.qwest.net (174.21.0.91) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30
TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-102.tukw.qwest.net (174.21.0.102)
Host is up (0.058s latency).
All 1000 scanned ports on 174-21-0-102.tukw.qwest.net (174.21.0.102) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port

RACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   285.92 ms 174-21-0-102.tukw.qwest.net (174.21.0.102)

Nmap scan report for 174-21-0-103.tukw.qwest.net (174.21.0.103)
Host is up (0.099s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
5101/tcp open  admdog?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (87%), Samsung CLP-315W printer (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Dell 1815dn printer (87%), VxWorks (87%), Xerox WorkCentre 4150 printer (86%), IBM OS/2 Warp 2.0 (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 5101/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   207.81 ms 174-21-0-103.tukw.qwest.net (174.21.0.103)

Nmap scan report for 174-21-0-104.tukw.qwest.net (174.21.0.104)
Host is up (0.00026s latency).
All 1000 scanned ports on 174-21-0-104.tukw.qwest.net (174.21.0.104) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-105.tukw.qwest.net (174.21.0.105)
Host is up (0.00018s latency).
All 1000 scanned ports on 174-21-0-105.tukw.qwest.net (174.21.0.105) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-106.tukw.qwest.net (174.21.0.106)
Host is up (0.00023s latency).
All 1000 scanned ports on 174-21-0-106.tukw.qwest.net (174.21.0.106) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.6
3   ... 30

Nmap scan report for 174-21-0-107.tukw.qwest.net (174.21.0.107)
Host is up (0.00021s latency).
All 1000 scanned ports on 174-21-0-107.tukw.qwest.net (174.21.0.107) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-108.tukw.qwest.net (174.21.0.108)
Host is up (0.14s latency).
All 1000 scanned ports on 174-21-0-108.tukw.qwest.net (174.21.0.108) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   184.29 ms 174-21-0-108.tukw.qwest.net (174.21.0.108)

Nmap scan report for 174-21-0-109.tukw.qwest.net (174.21.0.109)
Host is up (0.13s latency).
Not shown: 998 filtered tcp ports (no-response)
PORT     STATE SERVICE  VERSION
443/tcp  open  ssl/http nginx
| tls-alpn:
|_  http/1.1
|_http-title: 403 Forbidden
|_ssl-date: TLS randomness does not represent time
| ssl-cert: Subject: organizationName=Technicolor/stateOrProvinceName=Antwerp/countryName=BE
| Not valid before: 2019-12-10T02:17:40
|_Not valid after:  2029-12-07T02:17:40
4567/tcp open  http     Thomson DSL router TR-069
|_http-title: Site doesn't have a title.
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (89%), Samsung CLP-315W printer (88%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (87%), Dell 1815dn printer (87%), VxWorks (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Xerox WorkCentre 4150 printer (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Device: broadband router

TRACEROUTE (using port 443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   427.72 ms 174.21.0.109

Nmap scan report for 174-21-0-110.tukw.qwest.net (174.21.0.110)
Host is up (0.15s latency).
All 1000 scanned ports on 174-21-0-110.tukw.qwest.net (174.21.0.110) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   235.75 ms 174.21.0.110

Nmap scan report for 174-21-0-111.tukw.qwest.net (174.21.0.111)
Host is up (0.13s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
5101/tcp open  admdog?
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (88%), Samsung CLP-315W printer (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (87%), Dell 1815dn printer (87%), VxWorks (87%), Xerox WorkCentre 4150 printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 5101/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   417.28 ms 174.21.0.111

Nmap scan report for 174-21-0-112.tukw.qwest.net (174.21.0.112)
Host is up (0.15s latency).
All 1000 scanned ports on 174-21-0-112.tukw.qwest.net (174.21.0.112) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   225.55 ms 174.21.0.112

Nmap scan report for 174-21-0-113.tukw.qwest.net (174.21.0.113)
Host is up (0.16s latency).
All 1000 scanned ports on 174-21-0-113.tukw.qwest.net (174.21.0.113) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   225.49 ms 174.21.0.113

Nmap scan report for 174-21-0-114.tukw.qwest.net (174.21.0.114)
Host is up (0.10s latency).
Not shown: 996 filtered tcp ports (no-response)
PORT     STATE  SERVICE VERSION
23/tcp   open   telnet  Broadcom BCM963268 ADSL router telnetd
443/tcp  closed https
4567/tcp open   tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1 401 Authorization Required
|_    Content-Length: 0
5060/tcp closed sip
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E96B0D%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,3A,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-L
SF:ength:\x200\r\n\r\n")%r(HTTPOptions,3A,"HTTP/1\.1\x20401\x20Authorizati
SF:on\x20Required\r\nContent-Length:\x200\r\n\r\n")%r(FourOhFourRequest,3A
SF:,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-Length:\x200
SF:\r\n\r\n");
Device type: bridge|general purpose|switch|broadband router|media device
Running (JUST GUESSING): Oracle Virtualbox (98%), QEMU (96%), Bay Networks embedded (91%), Allied Telesyn embedded (90%), Linux (89%), Netgear embedded (89%), Sling embedded (88%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450 cpe:/h:alliedtelesyn:at-9006 cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:netgear:rt311 cpe:/h:slingmedia:slingbox_av
Aggressive OS guesses: Oracle Virtualbox (98%), QEMU user mode network gateway (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (90%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (89%), Netgear RT311 broadband router (89%), Slingmedia Slingbox AV TV over IP gateway (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Device: broadband router; CPE: cpe:/h:broadcom:bcm963268

TRACEROUTE (using port 443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   216.60 ms 174.21.0.114

Nmap scan report for 174-21-0-115.tukw.qwest.net (174.21.0.115)
Host is up (0.13s latency).
All 1000 scanned ports on 174-21-0-115.tukw.qwest.net (174.21.0.115) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   140.64 ms 174-21-0-115.tukw.qwest.net (174.21.0.115)

Nmap scan report for 174-21-0-116.tukw.qwest.net (174.21.0.116)
Host is up (0.10s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1
|_    Connection: close
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E96B0D%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(HTTPOptions,
SF:1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(FourOhFourRequest,1F,
SF:"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n");
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (97%), Oracle Virtualbox (95%), Bay Networks embedded (90%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450
Aggressive OS guesses: QEMU user mode network gateway (97%), Oracle Virtualbox (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 4567/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   206.29 ms 174-21-0-116.tukw.qwest.net (174.21.0.116)

Nmap scan report for 174-21-0-117.tukw.qwest.net (174.21.0.117)
Host is up (0.00029s latency).
All 1000 scanned ports on 174-21-0-117.tukw.qwest.net (174.21.0.117) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   ... 30

Nmap scan report for 174-21-0-118.tukw.qwest.net (174.21.0.118)
Host is up (0.11s latency).
All 1000 scanned ports on 174-21-0-118.tukw.qwest.net (174.21.0.118) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   130.44 ms 174.21.0.118

Nmap scan report for 174-21-0-119.tukw.qwest.net (174.21.0.119)
Host is up (0.12s latency).
Not shown: 998 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1
|_    Connection: close
5101/tcp open  admdog?
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E96B0D%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(HTTPOptions,
SF:1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(FourOhFourRequest,1F,
SF:"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n");
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (95%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (87%), Samsung CLP-315W printer (87%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (86%), Dell 1815dn printer (86%), VxWorks (86%), IBM OS/2 Warp 2.0 (86%), Xerox WorkCentre 4150 printer (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 5101/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   206.11 ms 174.21.0.119

Nmap scan report for 174-21-0-120.tukw.qwest.net (174.21.0.120)
Host is up (0.00028s latency).
All 1000 scanned ports on 174-21-0-120.tukw.qwest.net (174.21.0.120) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-121.tukw.qwest.net (174.21.0.121)
Host is up (0.00021s latency).
All 1000 scanned ports on 174-21-0-121.tukw.qwest.net (174.21.0.121) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-122.tukw.qwest.net (174.21.0.122)
Host is up (0.089s latency).
All 1000 scanned ports on 174-21-0-122.tukw.qwest.net (174.21.0.122) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   123.18 ms 174.21.0.122

Nmap scan report for 174-21-0-123.tukw.qwest.net (174.21.0.123)
Host is up (0.00021s latency).
All 1000 scanned ports on 174-21-0-123.tukw.qwest.net (174.21.0.123) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-124.tukw.qwest.net (174.21.0.124)
Host is up (0.094s latency).
All 1000 scanned ports on 174-21-0-124.tukw.qwest.net (174.21.0.124) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   123.21 ms 174.21.0.124

Nmap scan report for 174-21-0-125.tukw.qwest.net (174.21.0.125)
Host is up (0.00018s latency).
All 1000 scanned ports on 174-21-0-125.tukw.qwest.net (174.21.0.125) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   ... 30

Nmap scan report for 174-21-0-126.tukw.qwest.net (174.21.0.126)
Host is up (0.00019s latency).
All 1000 scanned ports on 174-21-0-126.tukw.qwest.net (174.21.0.126) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.6
2   ... 30

Nmap scan report for 174-21-0-127.tukw.qwest.net (174.21.0.127)
Host is up (0.10s latency).
All 1000 scanned ports on 174-21-0-127.tukw.qwest.net (174.21.0.127) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.6
4   186.62 ms 174.21.0.127

RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
Nmap scan report for 174-21-0-128.tukw.qwest.net (174.21.0.128)
Host is up (0.18s latency).
All 1000 scanned ports on 174-21-0-128.tukw.qwest.net (174.21.0.128) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
1   0.33 ms   10.0.2.2
2   5.84 ms   modem (192.168.0.1)
3   71.39 ms  tukw-dsl-gw75.tukw.qwest.net (63.231.10.75)
4   136.53 ms 174-21-0-128.tukw.qwest.net (174.21.0.128)

Nmap scan report for 174-21-0-129.tukw.qwest.net (174.21.0.129)
Host is up (0.00024s latency).
All 1000 scanned ports on 174-21-0-129.tukw.qwest.net (174.21.0.129) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-130.tukw.qwest.net (174.21.0.130)
Host is up (0.18s latency).
All 1000 scanned ports on 174-21-0-130.tukw.qwest.net (174.21.0.130) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   123.61 ms 174-21-0-130.tukw.qwest.net (174.21.0.130)

Nmap scan report for 174-21-0-131.tukw.qwest.net (174.21.0.131)
Host is up (0.00038s latency).
All 1000 scanned ports on 174-21-0-131.tukw.qwest.net (174.21.0.131) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-132.tukw.qwest.net (174.21.0.132)
Host is up (0.00022s latency).
All 1000 scanned ports on 174-21-0-132.tukw.qwest.net (174.21.0.132) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-133.tukw.qwest.net (174.21.0.133)
Host is up (0.00025s latency).
All 1000 scanned ports on 174-21-0-133.tukw.qwest.net (174.21.0.133) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-134.tukw.qwest.net (174.21.0.134)
Host is up (0.18s latency).
All 1000 scanned ports on 174-21-0-134.tukw.qwest.net (174.21.0.134) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   133.19 ms 174-21-0-134.tukw.qwest.net (174.21.0.134)

Nmap scan report for 174-21-0-135.tukw.qwest.net (174.21.0.135)
Host is up (0.00021s latency).
All 1000 scanned ports on 174-21-0-135.tukw.qwest.net (174.21.0.135) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-136.tukw.qwest.net (174.21.0.136)
Host is up (0.17s latency).
All 1000 scanned ports on 174-21-0-136.tukw.qwest.net (174.21.0.136) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   107.20 ms 174-21-0-136.tukw.qwest.net (174.21.0.136)

Nmap scan report for 174-21-0-137.tukw.qwest.net (174.21.0.137)
Host is up (0.00022s latency).
All 1000 scanned ports on 174-21-0-137.tukw.qwest.net (174.21.0.137) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-138.tukw.qwest.net (174.21.0.138)
Host is up (0.00022s latency).
All 1000 scanned ports on 174-21-0-138.tukw.qwest.net (174.21.0.138) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-139.tukw.qwest.net (174.21.0.139)
Host is up (0.17s latency).
All 1000 scanned ports on 174-21-0-139.tukw.qwest.net (174.21.0.139) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   97.64 ms 174-21-0-139.tukw.qwest.net (174.21.0.139)

Nmap scan report for 174-21-0-140.tukw.qwest.net (174.21.0.140)
Host is up (0.17s latency).
All 1000 scanned ports on 174-21-0-140.tukw.qwest.net (174.21.0.140) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   96.71 ms 174-21-0-140.tukw.qwest.net (174.21.0.140)

Nmap scan report for 174-21-0-141.tukw.qwest.net (174.21.0.141)
Host is up (0.22s latency).
All 1000 scanned ports on 174-21-0-141.tukw.qwest.net (174.21.0.141) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   138.08 ms 174-21-0-141.tukw.qwest.net (174.21.0.141)

Nmap scan report for 174-21-0-142.tukw.qwest.net (174.21.0.142)
Host is up (0.00024s latency).
All 1000 scanned ports on 174-21-0-142.tukw.qwest.net (174.21.0.142) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-143.tukw.qwest.net (174.21.0.143)
Host is up (0.00023s latency).
All 1000 scanned ports on 174-21-0-143.tukw.qwest.net (174.21.0.143) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-144.tukw.qwest.net (174.21.0.144)
Host is up (0.058s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE    VERSION
4567/tcp open  tcpwrapped
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: Cisco Catalyst 1900 switch (91%), Nokia 3600i mobile phone (90%), Cisco ATA 188 VoIP adapter (89%), Apple Time Capsule NAS device (88%), QEMU user mode network gateway (88%), Linux 2.0.33 (86%), Aastra 6731i VoIP phone or Apple AirPort Express WAP (86%), Konica Minolta bizhub 250 printer (86%), GNU Hurd 0.3 (86%), Huawei Echolife HG520-series ADSL modem (86%)
No exact OS matches for host (test conditions non-ideal).

TRACEROUTE (using port 4567/tcp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-145.tukw.qwest.net (174.21.0.145)
Host is up (0.16s latency).
All 1000 scanned ports on 174-21-0-145.tukw.qwest.net (174.21.0.145) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

_____________________________________
+_______________________________
________________________________________
Host is up (0.00023s latency).
All 1000 scanned ports on 174-21-0-143.tukw.qwest.net (174.21.0.143) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-144.tukw.qwest.net (174.21.0.144)
Host is up (0.058s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE    VERSION
4567/tcp open  tcpwrapped
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: Cisco Catalyst 1900 switch (91%), Nokia 3600i mobile phone (90%), Cisco ATA 188 VoIP adapter (89%), Apple Time Capsule NAS device (88%), QEMU user mode network gateway (88%), Linux 2.0.33 (86%), Aastra 6731i VoIP phone or Apple AirPort Express WAP (86%), Konica Minolta bizhub 250 printer (86%), GNU Hurd 0.3 (86%), Huawei Echolife HG520-series ADSL modem (86%)
No exact OS matches for host (test conditions non-ideal).

TRACEROUTE (using port 4567/tcp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30
__________________________________________
____________________________________________________
_____________________________________________________________


TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   68.61 ms 174-21-0-155.tukw.qwest.net (174.21.0.155)

Nmap scan report for 174-21-0-156.tukw.qwest.net (174.21.0.156)
Host is up (0.093s latency).
Not shown: 998 filtered tcp ports (no-response)
PORT     STATE SERVICE  VERSION
443/tcp  open  ssl/http nginx
| ssl-cert: Subject: organizationName=Technicolor/stateOrProvinceName=Antwerp/countryName=BE
| Not valid before: 2019-12-10T02:17:46
|_Not valid after:  2029-12-07T02:17:46
|_ssl-date: TLS randomness does not represent time
| tls-alpn:
|_  http/1.1
|_http-title: 403 Forbidden
4567/tcp open  http     Thomson DSL router TR-069
|_http-title: Site doesn't have a title.
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Samsung CLP-315W printer (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), Dell 1815dn printer (86%), VxWorks (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Device: broadband router

TRACEROUTE (using port 443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   113.72 ms 174-21-0-156.tukw.qwest.net (174.21.0.156)

Nmap scan report for 174-21-0-157.tukw.qwest.net (174.21.0.157)
Host is up (0.19s latency).
All 1000 scanned ports on 174-21-0-157.tukw.qwest.net (174.21.0.157) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   65.84 ms 174-21-0-157.tukw.qwest.net (174.21.0.157)

Nmap scan report for 174-21-0-158.tukw.qwest.net (174.21.0.158)
Host is up (0.030s latency).
All 1000 scanned ports on 174-21-0-158.tukw.qwest.net (174.21.0.158) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   76.06 ms 174-21-0-158.tukw.qwest.net (174.21.0.158)

Nmap scan report for 174-21-0-159.tukw.qwest.net (174.21.0.159)
Host is up (0.19s latency).
All 1000 scanned ports on 174-21-0-159.tukw.qwest.net (174.21.0.159) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   69.09 ms 174-21-0-159.tukw.qwest.net (174.21.0.159)

Nmap scan report for 174-21-0-160.tukw.qwest.net (174.21.0.160)
Host is up (0.029s latency).
All 1000 scanned ports on 174-21-0-160.tukw.qwest.net (174.21.0.160) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   45.62 ms 174-21-0-160.tukw.qwest.net (174.21.0.160)

Nmap scan report for 174-21-0-161.tukw.qwest.net (174.21.0.161)
Host is up (0.031s latency).
All 1000 scanned ports on 174-21-0-161.tukw.qwest.net (174.21.0.161) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   65.98 ms 174-21-0-161.tukw.qwest.net (174.21.0.161)

Nmap scan report for 174-21-0-162.tukw.qwest.net (174.21.0.162)
Host is up (0.00023s latency).
All 1000 scanned ports on 174-21-0-162.tukw.qwest.net (174.21.0.162) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-163.tukw.qwest.net (174.21.0.163)
Host is up (0.032s latency).
All 1000 scanned ports on 174-21-0-163.tukw.qwest.net (174.21.0.163) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   76.26 ms 174-21-0-163.tukw.qwest.net (174.21.0.163)

Nmap scan report for 174-21-0-164.tukw.qwest.net (174.21.0.164)
Host is up (0.00026s latency).
All 1000 scanned ports on 174-21-0-164.tukw.qwest.net (174.21.0.164) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-165.tukw.qwest.net (174.21.0.165)
Host is up (0.029s latency).
All 1000 scanned ports on 174-21-0-165.tukw.qwest.net (174.21.0.165) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   53.19 ms 174-21-0-165.tukw.qwest.net (174.21.0.165)

Nmap scan report for 174-21-0-166.tukw.qwest.net (174.21.0.166)
Host is up (0.098s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT    STATE SERVICE  VERSION
443/tcp open  ssl/http nginx
| ssl-cert: Subject: organizationName=Technicolor/stateOrProvinceName=Antwerp/countryName=BE
| Not valid before: 2019-12-10T02:17:36
|_Not valid after:  2029-12-07T02:17:36
| tls-alpn:
|_  http/1.1
|_ssl-date: TLS randomness does not represent time
|_http-title: 400 The plain HTTP request was sent to HTTPS port
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Samsung CLP-315W printer (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), Dell 1815dn printer (86%), VxWorks (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   116.15 ms 174-21-0-166.tukw.qwest.net (174.21.0.166)

Nmap scan report for 174-21-0-167.tukw.qwest.net (174.21.0.167)
Host is up (0.031s latency).
All 1000 scanned ports on 174-21-0-167.tukw.qwest.net (174.21.0.167) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   67.44 ms 174-21-0-167.tukw.qwest.net (174.21.0.167)

Nmap scan report for 174-21-0-168.tukw.qwest.net (174.21.0.168)
Host is up (0.19s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1
|_    Connection: close
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E98033%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(HTTPOptions,
SF:1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(FourOhFourRequest,1F,
SF:"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n");
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (94%), Oracle Virtualbox (91%), Bay Networks embedded (86%), IBM OS/2 4.X (85%), Cisco embedded (85%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/o:ibm:os2:4 cpe:/h:cisco:sg_500
Aggressive OS guesses: QEMU user mode network gateway (94%), Oracle Virtualbox (91%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (86%), IBM OS/2 Warp 2.0 (85%), Cisco SG 500 switch (85%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 4567/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   106.36 ms 174-21-0-168.tukw.qwest.net (174.21.0.168)

Nmap scan report for 174-21-0-169.tukw.qwest.net (174.21.0.169)
Host is up (0.040s latency).
All 1000 scanned ports on 174-21-0-169.tukw.qwest.net (174.21.0.169) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   77.59 ms 174-21-0-169.tukw.qwest.net (174.21.0.169)

Nmap scan report for 174-21-0-170.tukw.qwest.net (174.21.0.170)
Host is up (0.044s latency).
All 1000 scanned ports on 174-21-0-170.tukw.qwest.net (174.21.0.170) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   95.84 ms 174-21-0-170.tukw.qwest.net (174.21.0.170)

Nmap scan report for 174-21-0-171.tukw.qwest.net (174.21.0.171)
Host is up (0.11s latency).
Not shown: 995 filtered tcp ports (no-response)
PORT     STATE  SERVICE    VERSION
80/tcp   closed http
554/tcp  open   rtsp       D-Link DCS-2130 or Pelco IDE10DN webcam rtspd
|_rtsp-methods: OPTIONS, DESCRIBE, SETUP, TEARDOWN, PLAY, PAUSE, GET_PARAMETER, SET_PARAMETER
1723/tcp open   pptp       MikroTik (Firmware: 1)
8291/tcp open   tcpwrapped
9999/tcp open   abyss?
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (89%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (88%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (87%), Dell 1815dn printer (87%), VxWorks (87%), Xerox WorkCentre 4150 printer (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Host: MikroTik; Device: webcam; CPE: cpe:/h:pelco:ide10dn

TRACEROUTE (using port 80/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   114.88 ms 174-21-0-171.tukw.qwest.net (174.21.0.171)

Nmap scan report for 174-21-0-172.tukw.qwest.net (174.21.0.172)
Host is up (0.10s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     Dropbear sshd 2016.74 (protocol 2.0)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (92%), Oracle Virtualbox (92%), Bay Networks embedded (87%), IBM OS/2 4.X (86%), IBM AIX 7.X (85%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/o:ibm:os2:4 cpe:/o:ibm:aix:7.1
Aggressive OS guesses: QEMU user mode network gateway (92%), Oracle Virtualbox (92%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (87%), IBM OS/2 Warp 2.0 (86%), IBM AIX 7.1 (85%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

TRACEROUTE (using port 22/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   126.31 ms 174-21-0-172.tukw.qwest.net (174.21.0.172)

Nmap scan report for 174-21-0-173.tukw.qwest.net (174.21.0.173)
Host is up (0.00032s latency).
All 1000 scanned ports on 174-21-0-173.tukw.qwest.net (174.21.0.173) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   ... 30

Nmap scan report for 174-21-0-174.tukw.qwest.net (174.21.0.174)
Host is up (0.11s latency).
All 1000 scanned ports on 174-21-0-174.tukw.qwest.net (174.21.0.174) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   45.62 ms 174-21-0-160.tukw.qwest.net (174.21.0.160)

Nmap scan report for 174-21-0-161.tukw.qwest.net (174.21.0.161)
Host is up (0.031s latency).
All 1000 scanned ports on 174-21-0-161.tukw.qwest.net (174.21.0.161) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   65.98 ms 174-21-0-161.tukw.qwest.net (174.21.0.161)

Nmap scan report for 174-21-0-162.tukw.qwest.net (174.21.0.162)
Host is up (0.00023s latency).
All 1000 scanned ports on 174-21-0-162.tukw.qwest.net (174.21.0.162) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-163.tukw.qwest.net (174.21.0.163)
Host is up (0.032s latency).
All 1000 scanned ports on 174-21-0-163.tukw.qwest.net (174.21.0.163) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   76.26 ms 174-21-0-163.tukw.qwest.net (174.21.0.163)

Nmap scan report for 174-21-0-164.tukw.qwest.net (174.21.0.164)
Host is up (0.00026s latency).
All 1000 scanned ports on 174-21-0-164.tukw.qwest.net (174.21.0.164) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   53.19 ms 174-21-0-165.tukw.qwest.net (174.21.0.165)

Nmap scan report for 174-21-0-166.tukw.qwest.net (174.21.0.166)
Host is up (0.098s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT    STATE SERVICE  VERSION
443/tcp open  ssl/http nginx
| ssl-cert: Subject: organizationName=Technicolor/stateOrProvinceName=Antwerp/countryName=BE
| Not valid before: 2019-12-10T02:17:36
|_Not valid after:  2029-12-07T02:17:36
| tls-alpn:
|_  http/1.1
|_ssl-date: TLS randomness does not represent time
|_http-title: 400 The plain HTTP request was sent to HTTPS port
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (90%), Allied Telesyn AT-9006SX/SC switch (88%), Slingmedia Slingbox AV TV over IP gateway (88%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Samsung CLP-315W printer (87%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (86%), Dell 1815dn printer (86%), VxWorks (86%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 443/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   116.15 ms 174-21-0-166.tukw.qwest.net (174.21.0.166)

Nmap scan report for 174-21-0-167.tukw.qwest.net (174.21.0.167)
Host is up (0.031s latency).
All 1000 scanned ports on 174-21-0-167.tukw.qwest.net (174.21.0.167) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   67.44 ms 174-21-0-167.tukw.qwest.net (174.21.0.167)

Nmap scan report for 174-21-0-168.tukw.qwest.net (174.21.0.168)
Host is up (0.19s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
4567/tcp open  tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1
|_    Connection: close
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E98033%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(HTTPOptions,
SF:1F,"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n")%r(FourOhFourRequest,1F,
SF:"HTTP/1\.1\r\nConnection:\x20close\r\n\r\n");
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (94%), Oracle Virtualbox (91%), Bay Networks embedded (86%), IBM OS/2 4.X (85%), Cisco embedded (85%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/o:ibm:os2:4 cpe:/h:cisco:sg_500
Aggressive OS guesses: QEMU user mode network gateway (94%), Oracle Virtualbox (91%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (86%), IBM OS/2 Warp 2.0 (85%), Cisco SG 500 switch (85%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 4567/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   106.36 ms 174-21-0-168.tukw.qwest.net (174.21.0.168)

Nmap scan report for 174-21-0-169.tukw.qwest.net (174.21.0.169)
Host is up (0.040s latency).
All 1000 scanned ports on 174-21-0-169.tukw.qwest.net (174.21.0.169) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   77.59 ms 174-21-0-169.tukw.qwest.net (174.21.0.169)

Nmap scan report for 174-21-0-170.tukw.qwest.net (174.21.0.170)
Host is up (0.044s latency).
All 1000 scanned ports on 174-21-0-170.tukw.qwest.net (174.21.0.170) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   95.84 ms 174-21-0-170.tukw.qwest.net (174.21.0.170)

Nmap scan report for 174-21-0-171.tukw.qwest.net (174.21.0.171)
Host is up (0.11s latency).
Not shown: 995 filtered tcp ports (no-response)
PORT     STATE  SERVICE    VERSION
80/tcp   closed http
554/tcp  open   rtsp       D-Link DCS-2130 or Pelco IDE10DN webcam rtspd
|_rtsp-methods: OPTIONS, DESCRIBE, SETUP, TEARDOWN, PLAY, PAUSE, GET_PARAMETER, SET_PARAMETER
1723/tcp open   pptp       MikroTik (Firmware: 1)
8291/tcp open   tcpwrapped
9999/tcp open   abyss?
Aggressive OS guesses: QEMU user mode network gateway (96%), Oracle Virtualbox (96%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (91%), Allied Telesyn AT-9006SX/SC switch (89%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (88%), Samsung CLP-315W printer (88%), Bay Networks BayStack 450 switch (software version 4.2.0.16) (87%), Dell 1815dn printer (87%), VxWorks (87%), Xerox WorkCentre 4150 printer (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Host: MikroTik; Device: webcam; CPE: cpe:/h:pelco:ide10dn

TRACEROUTE (using port 80/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   114.88 ms 174-21-0-171.tukw.qwest.net (174.21.0.171)

Nmap scan report for 174-21-0-172.tukw.qwest.net (174.21.0.172)
Host is up (0.10s latency).
Not shown: 999 filtered tcp ports (no-response)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     Dropbear sshd 2016.74 (protocol 2.0)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: general purpose|bridge|switch
Running (JUST GUESSING): QEMU (92%), Oracle Virtualbox (92%), Bay Networks embedded (87%), IBM OS/2 4.X (86%), IBM AIX 7.X (85%)
OS CPE: cpe:/a:qemu:qemu cpe:/o:oracle:virtualbox cpe:/h:baynetworks:baystack_450 cpe:/o:ibm:os2:4 cpe:/o:ibm:aix:7.1
Aggressive OS guesses: QEMU user mode network gateway (92%), Oracle Virtualbox (92%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (87%), IBM OS/2 Warp 2.0 (86%), IBM AIX 7.1 (85%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

TRACEROUTE (using port 22/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   126.31 ms 174-21-0-172.tukw.qwest.net (174.21.0.172)

Nmap scan report for 174-21-0-173.tukw.qwest.net (174.21.0.173)
Host is up (0.00032s latency).
All 1000 scanned ports on 174-21-0-173.tukw.qwest.net (174.21.0.173) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   ... 30

Nmap scan report for 174-21-0-174.tukw.qwest.net (174.21.0.174)
Host is up (0.11s latency).
All 1000 scanned ports on 174-21-0-174.tukw.qwest.net (174.21.0.174) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   117.57 ms 174-21-0-174.tukw.qwest.net (174.21.0.174)

Nmap scan report for 174-21-0-175.tukw.qwest.net (174.21.0.175)
Host is up (0.084s latency).
All 1000 scanned ports on 174-21-0-175.tukw.qwest.net (174.21.0.175) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   113.20 ms 174-21-0-175.tukw.qwest.net (174.21.0.175)

Nmap scan report for 174-21-0-176.tukw.qwest.net (174.21.0.176)
Host is up (0.16s latency).
Not shown: 998 closed tcp ports (reset)
PORT     STATE    SERVICE VERSION
25/tcp   filtered smtp
4567/tcp open     tram?
| fingerprint-strings:
|   FourOhFourRequest, GetRequest, HTTPOptions:
|     HTTP/1.1 401 Authorization Required
|_    Content-Length: 0
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port4567-TCP:V=7.93%I=7%D=2/12%Time=63E98034%P=x86_64-pc-linux-gnu%r(Ge
SF:tRequest,3A,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-L
SF:ength:\x200\r\n\r\n")%r(HTTPOptions,3A,"HTTP/1\.1\x20401\x20Authorizati
SF:on\x20Required\r\nContent-Length:\x200\r\n\r\n")%r(FourOhFourRequest,3A
SF:,"HTTP/1\.1\x20401\x20Authorization\x20Required\r\nContent-Length:\x200
SF:\r\n\r\n");
Aggressive OS guesses: QEMU user mode network gateway (93%), Linux 2.6.18 (CentOS 5, x86_64, SMP) (87%), Slingmedia Slingbox AV TV over IP gateway (87%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (87%), GNU Hurd 0.3 (87%), Allied Telesyn AT-9006SX/SC switch (86%), HP 9100c Digital Sender printer (J3113A) (86%), Minolta Di550 laser printer (86%), NEC SuperScript printer (86%), Konica Minolta 7035 printer (85%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 3 hops

TRACEROUTE (using port 143/tcp)
HOP RTT       ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ...
3   118.23 ms 174-21-0-176.tukw.qwest.net (174.21.0.176)

Nmap scan report for 174-21-0-177.tukw.qwest.net (174.21.0.177)
Host is up (0.0011s latency).
All 1000 scanned ports on 174-21-0-177.tukw.qwest.net (174.21.0.177) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-178.tukw.qwest.net (174.21.0.178)
Host is up (0.0010s latency).
All 1000 scanned ports on 174-21-0-178.tukw.qwest.net (174.21.0.178) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-179.tukw.qwest.net (174.21.0.179)
Host is up (0.15s latency).
All 1000 scanned ports on 174-21-0-179.tukw.qwest.net (174.21.0.179) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   91.68 ms 174-21-0-179.tukw.qwest.net (174.21.0.179)

Nmap scan report for 174-21-0-180.tukw.qwest.net (174.21.0.180)
Host is up (0.17s latency).
All 1000 scanned ports on 174-21-0-180.tukw.qwest.net (174.21.0.180) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   120.36 ms 174-21-0-180.tukw.qwest.net (174.21.0.180)

Nmap scan report for 174-21-0-181.tukw.qwest.net (174.21.0.181)
Host is up (0.14s latency).
All 1000 scanned ports on 174-21-0-181.tukw.qwest.net (174.21.0.181) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   92.94 ms 174-21-0-181.tukw.qwest.net (174.21.0.181)

Nmap scan report for 174-21-0-182.tukw.qwest.net (174.21.0.182)
Host is up (0.18s latency).
All 1000 scanned ports on 174-21-0-182.tukw.qwest.net (174.21.0.182) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   120.36 ms 174-21-0-182.tukw.qwest.net (174.21.0.182)

Nmap scan report for 174-21-0-183.tukw.qwest.net (174.21.0.183)
Host is up (0.00099s latency).
All 1000 scanned ports on 174-21-0-183.tukw.qwest.net (174.21.0.183) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   ... 30

Nmap scan report for 174-21-0-184.tukw.qwest.net (174.21.0.184)
Host is up (0.25s latency).
All 1000 scanned ports on 174-21-0-184.tukw.qwest.net (174.21.0.184) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   297.53 ms 174-21-0-184.tukw.qwest.net (174.21.0.184)

Nmap scan report for 174-21-0-185.tukw.qwest.net (174.21.0.185)
Host is up (0.00023s latency).
All 1000 scanned ports on 174-21-0-185.tukw.qwest.net (174.21.0.185) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-186.tukw.qwest.net (174.21.0.186)
Host is up (0.00022s latency).
All 1000 scanned ports on 174-21-0-186.tukw.qwest.net (174.21.0.186) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hop 1 is the same as for 174.21.0.128
2   ... 30

Nmap scan report for 174-21-0-187.tukw.qwest.net (174.21.0.187)
Host is up (0.15s latency).
All 1000 scanned ports on 174-21-0-187.tukw.qwest.net (174.21.0.187) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   102.85 ms 174-21-0-187.tukw.qwest.net (174.21.0.187)

Nmap scan report for 174-21-0-188.tukw.qwest.net (174.21.0.188)
Host is up (0.16s latency).
All 1000 scanned ports on 174-21-0-188.tukw.qwest.net (174.21.0.188) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   115.38 ms 174-21-0-188.tukw.qwest.net (174.21.0.188)

Nmap scan report for 174-21-0-189.tukw.qwest.net (174.21.0.189)
Host is up (0.16s latency).
All 1000 scanned ports on 174-21-0-189.tukw.qwest.net (174.21.0.189) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
-   Hops 1-3 are the same as for 174.21.0.128
4   93.58 ms 174-21-0-189.tukw.qwest.net (174.21.0.189)

Nmap scan report for 174-21-0-190.tukw.qwest.net (174.21.0.190)
Host is up (0.00020s latency).
All 1000 scanned ports on 174-21-0-190.tukw.qwest.net (174.21.0.190) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Too many fingerprints match this host to give specific OS details

TRACEROUTE (using proto 1/icmp)
HOP RTT    ADDRESS
-   Hops 1-2 are the same as for 174.21.0.128
3   ... 30

Nmap scan report for 174-21-0-191.tukw.qwest.net (174.21.0.191)
Host is up (0.15s latency).
All 1000 scanned ports on 174-21-0-191.tukw.qwest.net (174.21.0.191) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, QEMU, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/a:qemu:qemu cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, QEMU user mode network gateway, Vantage HD7100S satellite receiver
Sent with Proton Mail secure email.
