                12.5Kb          25.0Kb          37.5Kb          50.0Kb    62.5Kb
└───────────────┴───────────────┴───────────────┴───────────────┴───────────────
davidmartinez              => _gateway                      0b      0b      0b
                           <=                               0b      0b     67b
davidmartinez              => 204.44.81.158                 0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 144.76.199.183                0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 193.218.118.100               0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 91.236.239.79                 0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 171.22.136.83                 0b      0b     12b
                           <=                               0b      0b      0b
────────────────────────────────────────────────────────────────────────────────
TX:             cum:   16.2KB   peak:    960b   rates:      0b      0b     72b
RX:                    15.7KB            896b               0b      0b     67b
TOTAL:                 31.9KB           1.81Kb              0b      0b    139b 

                12.5Kb          25.0Kb          37.5Kb          50.0Kb    62.5Kb
└───────────────┴───────────────┴───────────────┴───────────────┴───────────────
davidmartinez              => _gateway                      0b      0b      0b
                           <=                               0b      0b     78b
davidmartinez              => 116.202.169.25                0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 31.14.238.43                  0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 54.36.205.38                  0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 142.132.254.168               0b      0b     12b
                           <=                               0b      0b      0b
davidmartinez              => 77.174.62.158                 0b      0b     12b
                           <=                               0b      0b      0b
────────────────────────────────────────────────────────────────────────────────
TX:             cum:   17.4KB   peak:    960b   rates:      0b      0b     84b
RX:                    16.8KB            896b               0b      0b     78b
TOTAL:                 34.2KB           1.81Kb              0b      0b    162b 
