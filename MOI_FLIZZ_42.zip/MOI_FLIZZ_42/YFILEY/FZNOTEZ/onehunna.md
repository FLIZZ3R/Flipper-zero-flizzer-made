 PORT     STATE SERVICE            VERSION
3389/tcp open  ssl/ms-wbt-server?
| rdp-ntlm-info: 
|   Target_Name: MRSPOCK
|   NetBIOS_Domain_Name: MRSPOCK
|   NetBIOS_Computer_Name: MRSPOCK
|   DNS_Domain_Name: MrSpock
|   DNS_Computer_Name: MrSpock
|   Product_Version: 10.0.22000
|_  System_Time: 2023-02-22T06:19:13+00:00
|_ssl-date: 2023-02-22T06:19:20+00:00; +36s from scanner time.
| ssl-cert: Subject: commonName=MrSpock
| Not valid before: 2023-01-15T07:49:44
|_Not valid after:  2023-07-17T07:49:44
Device type: bridge|general purpose|switch
Running (JUST GUESSING): Oracle Virtualbox (96%), QEMU (94%), Bay Networks embedded (87%)
OS CPE: cpe:/o:oracle:virtualbox cpe:/a:qemu:qemu cpe:/h:baynetworks:baystack_450
Aggressive OS guess: Oracle Virtualbox (96%), QEMU user mode network gateway (94%), Bay Networks BayStack 450 switch (software version 3.1.0.22) (87%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 23 hops

Host script results:
|_clock-skew: mean: 35s, deviation: 0s, median: 35s

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
1   2.15 ms   10.0.2.2
2   6.98 ms   modem (192.168.0.1)
3   70.22 ms  tukw-dsl-gw75.tukw.qwest.net (63.231.10.75)
4   68.80 ms  tukw-agw1.inet.qwest.net (63.226.198.81)
5   ...
6   67.35 ms  4.69.219.210
7   65.97 ms  ae-10.a03.sttlwa01.us.bb.gin.ntt.net (129.250.9.180)
8   70.11 ms  ae-3.r24.sttlwa01.us.bb.gin.ntt.net (129.250.2.98)
9   122.49 ms ae-11.r20.nwrknj03.us.bb.gin.ntt.net (129.250.6.176)
10  185.95 ms ae-9.r20.londen12.uk.bb.gin.ntt.net (129.250.6.146)
11  187.33 ms ae-1.r21.londen12.uk.bb.gin.ntt.net (129.250.2.183)
12  199.82 ms ae-16.r20.frnkge13.de.bb.gin.ntt.net (129.250.3.13)
13  266.71 ms ae-0.a03.frnkge07.de.bb.gin.ntt.net (129.250.7.16)
14  233.50 ms et-0-0-5-0.bbr02.anx82.fra.de.anexia-it.net (213.198.83.166)
15  237.74 ms ae1-0.bbr02.anx25.fra.de.anexia-it.net (144.208.208.149)
16  239.04 ms ae1-0.bbr01.anx84.nue.de.anexia-it.net (144.208.208.140)
17  199.53 ms 94.16.25.77
18  198.53 ms 46.38.252.42
19  ... 22
23  491.14 ms v2202204121735186950.powersrv.de (185.16.60.130)

OS and Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .

 v2202204121735186950.powersrv.de (185.16.60.130)
 65531 filtered tcp ports (no-response)
PORT     STATE SERVICE            VERSION
3389/tcp open  ssl/ms-wbt-server?
7680/tcp open  pando-pub?
9035/tcp open  tor-info           Tor nodes info httpd
9099/tcp open  tcpwrapped
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: bridge
Running: Oracle Virtualbox
OS CPE: cpe:/o:oracle:virtualbox
OS details: Oracle Virtualbox

cp        0      0 127.0.0.1:9050          127.0.0.1:53490         ESTABLISHED
tcp        0      0 10.0.2.15:50652         185.16.60.130:9099      ESTABLISHED
tcp        0      0 127.0.0.1:53490         127.0.0.1:9050          ESTABLISHED
udp        0      0 10.0.2.15:45902         174.21.0.81:1434        ESTABLISHED
udp        0      0 10.0.2.15:33736         174.21.0.119:1434       ESTABLISHED
udp        0      0 10.0.2.15:50385         174.21.0.98:1434        ESTABLISHED
udp        0      0 10.0.2.15:58739         174.21.0.105:1434       ESTABLISHED
udp        0      0 10.0.2.15:60822         174.21.0.93:1434        ESTABLISHED
udp        0      0 10.0.2.15:34218         174.21.0.123:1434       ESTABLISHED
udp        0      0 10.0.2.15:48766         174.21.0.110:1434       ESTABLISHED
udp        0      0 10.0.2.15:46725         174.21.0.125:1434       ESTABLISHED
udp        0      0 10.0.2.15:57046         174.21.0.87:1434        ESTABLISHED
udp        0      0 10.0.2.15:68            10.0.2.2:67             ESTABLISHED
udp        0      0 10.0.2.15:51284         174.21.0.92:1434        ESTABLISHED
udp        0      0 10.0.2.15:47561         174.21.0.122:1434       ESTABLISHED
udp        0      0 10.0.2.15:39441         174.21.0.126:1434       ESTABLISHED

affiliate addys 185.16.60.130
p_dnsneighbor               	Affiliate - IP Address                       	185.16.60.128
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.129
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.131
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.132
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.133
neighbor               	Affiliate - IP Address                       	185.16.60.134
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.135
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.136
[proxychains] Dynamic chain  ...  127.0.0.1:9050  ...  ipapi.co:443 sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.137
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.138
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.139
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.140
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.141
sfp_dnsneighbor               	Affiliate - IP Address                       	185.16.60.142
sfp_dnsneighbor               	Affiliate - I 
P Address                       	185.16.60.143
fp_dnsresolve                	Affiliate - Domain Name                      	powersrv.de
sfp_dnsresolve                	Affiliate - IP Address                       	224.0.0.69
sfp_dnsresolve                	Affiliate - IP Address                       	46.38.243.234
], ['powersrv.p', 'p'], ['powersrv.s', 's'], ['powersrv.:', ':']]
sfp_dnsresolve                	Affiliate - Domain Name                      	netcup.net
sfp_dnsresolve 22                	Affiliate - IP Address                       	37.221.199.199
sfp_dnsresolve                	Affiliate - IP Address                       	224.0.0.70


        0      0 192.168.0.5:33198       185.16.60.130:9099      ESTABLISHED
tcp        0      0 192.168.0.5:42296       45.15.166.47:443        ESTABLISHED
udp        0      0 192.168.0.5:32830       192.168.0.1:53          ESTABLISHED
udp        0      0 192.168.0.5:68          192.168.0.1:67          ESTABLISHED
udp        0      0 192.168.0.5:53998       192.168.0.1:53          ESTABLISHED

 FOUND ON IRIS

192.168.0.1
127.0.0.53

