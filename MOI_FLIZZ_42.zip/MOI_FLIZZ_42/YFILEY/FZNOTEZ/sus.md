USPISION IS BUILDING
-people trying to scare or kill me discount tire
-gasslighting whole time at springlake possibly iris has stoped mostly
since her working
              seprate instances?
-tried to connect with community about gasslighting fake call from Springlake
i presume to turn me off
-implemented bars and locks on doors for when were at home
-attempted breakins Springlake working at discount after maxs death
-continued harrasment knocking on doors walls turning nob
trying to scare me or make me say something threatening
-hacking at the highest level, strang subghz signals, picturs dissapering
, alterd recordings, privicy invasion
-begining to hack back bought flipper and got linux kali...looking for
 hackers or PRIVATE EYES!!! keith experiencing some same occourances
-keith tells me about what was happening possible things i can do
APROX-1-MONTH LATER:keith in hospital unknown desieses I PRESUME POISONED
-FELT STRANGE ABOUT KEITH SHAREING INFORMATION FELT DANGEROUS
-KEITHS HOSPITALIZATION UNDER WRAPS BY IRIS?? WHY??
