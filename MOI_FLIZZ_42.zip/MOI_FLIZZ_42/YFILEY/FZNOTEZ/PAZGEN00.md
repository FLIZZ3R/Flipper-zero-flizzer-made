import random

chars = 'cbadefghilkjmnoqprstuvzyxw○♤♡◇♧1423657890ABCDEFGHIJKLMNOPQRVUTSWXYZ1234567890}(".^:;}<=+@¿?,# !<=+÷][~`$ />%-_^&*.'
number = input('Number of passwords - ')
number = int(number)

length = input('password length? - ')
length = int(length)

answer = input

for P in range(number):
    password = ''
for C in range(length):
    password += random.choice(chars)
    print(password)


passwd = open("passkey.txt", "a")
passwd.write(password)
passwd.close()

file = open('passlist', 'w')
file.write(password)
file.close()
