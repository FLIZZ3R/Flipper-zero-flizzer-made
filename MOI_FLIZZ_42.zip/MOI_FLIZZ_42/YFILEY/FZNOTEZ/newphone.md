st is up (0.73s latency).
All 1000 scanned ports on unn-89-187-185-184.cdn77.com (89.187.185.184) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: webcam|general purpose|broadband router|game console
Running: AXIS embedded, Linux, Netgear embedded, QEMU, Sony embedded
OS CPE: cpe:/h:axis:2100_network_camera cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:netgear:rt311 cpe:/a:qemu:qemu cpe:/h:sony:playstation_2
OS details: AXIS 2100 Network Camera, Linux 2.6.18 (CentOS 5, x86_64, SMP), Netgear RT311 broadband router, QEMU user mode network gateway, Sony PlayStation 2 game console test kit 2.2.1
Network Distance: 10 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
-   Hops 1-4 are the same as for 63.226.198.81
5   ...
6   881.15 ms TATA-level3-Seattle2.Level3.net (4.68.127.94)
7   344.80 ms if-ae-20-2.tcore1.sv1-santaclara.as6453.net (64.86.123.95)
8   367.99 ms if-ae-8-3.tcore1.lvw-losangeles.as6453.net (63.243.250.59)
9   ...
10  726.65 ms unn-89-187-185-184.cdn77.com (89.187.185.184)

Nmap scan report for modem (192.168.0.1)
Host is up (0.18s latency).
Not shown: 991 closed tcp ports (reset)
PORT      STATE SERVICE    VERSION
53/tcp    open  tcpwrapped
80/tcp    open  tcpwrapped
443/tcp   open  tcpwrapped
2601/tcp  open  tcpwrapped
2602/tcp  open  tcpwrapped
5000/tcp  open  tcpwrapped
5001/tcp  open  tcpwrapped
8080/tcp  open  tcpwrapped
49152/tcp open  tcpwrapped
Aggressive OS guesses: Cisco IP Phone 7941 (89%), Cisco IP Phone 7961G (89%), DYMO LabelManager Wireless PNP printer (89%), Efficient Networks SpeedStream 4100 ADSL router (89%), GlobespanVirata GS8100, Huawei MT880, or Solwise SAR 100 ADSL modem (89%), Lantronix XPort AR (89%), Motorola SURFboard SB5100i cable modem (89%), Cisco IP Phone 7942G (89%), Cisco Adaptive Security Appliance (ASA 8.4) (88%), Fortinet FortiGate 100D firewall (88%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops

TRACEROUTE (using port 22/tcp)
HOP RTT ADDRESS
-   Hops 1-2 are the same as for 63.226.198.81

Nmap scan report for tukw-dsl-gw75.tukw.qwest.net (63.231.10.75)
Host is up (0.55s latency).
All 1000 scanned ports on tukw-dsl-gw75.tukw.qwest.net (63.231.10.75) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Aggressive OS guesses: QEMU user mode network gateway (97%), DragonFly BSD 1.10.1 (95%), FreeBSD 4.11-RELEASE (x86) (95%), FreeBSD 4.11-STABLE (95%), FreeNAS 0.686 (FreeBSD 6.2-RELEASE) (95%), HP 2424M ProCurve switch (J4093A) (95%), HP ProCurve 2650, 2824, 2848, or 5300xl switch (95%), Juniper J4350 router (95%), Arris Cadant C3 cable modem terminator (VxWorks 5.4.2) (95%), HP LaserJet 3600 printer, HP ProCurve 2650 switch, or Motorola SURFboard SB5100E cable modem (95%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 3 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT ADDRESS
-   Hops 1-3 are the same as for 63.226.198.81

Nmap scan report for 63-226-198-81.tukw.qwest.net (63.226.198.81)
Host is up (0.59s latency).
All 1000 scanned ports on 63-226-198-81.tukw.qwest.net (63.226.198.81) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: webcam|general purpose|broadband router|game console
Running: AXIS embedded, Linux, Netgear embedded, QEMU, Sony embedded
OS CPE: cpe:/h:axis:2100_network_camera cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:netgear:rt311 cpe:/a:qemu:qemu cpe:/h:sony:playstation_2
OS details: AXIS 2100 Network Camera, Linux 2.6.18 (CentOS 5, x86_64, SMP), Netgear RT311 broadband router, QEMU user mode network gateway, Sony PlayStation 2 game console test kit 2.2.1
Network Distance: 4 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
1   5.86 ms   10.0.2.2
2   271.85 ms modem (192.168.0.1)
3   352.49 ms tukw-dsl-gw75.tukw.qwest.net (63.231.10.75)
4   442.36 ms 63-226-198-81.tukw.qwest.net (63.226.198.81)

Nmap scan report for TATA-level3-Seattle2.Level3.net (4.68.127.94)
Host is up (0.72s latency).
All 1000 scanned ports on TATA-level3-Seattle2.Level3.net (4.68.127.94) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: webcam|general purpose|broadband router|game console
Running: AXIS embedded, Linux, Netgear embedded, QEMU, Sony embedded
OS CPE: cpe:/h:axis:2100_network_camera cpe:/o:linux:linux_kernel:2.6.18 cpe:/h:netgear:rt311 cpe:/a:qemu:qemu cpe:/h:sony:playstation_2
OS details: AXIS 2100 Network Camera, Linux 2.6.18 (CentOS 5, x86_64, SMP), Netgear RT311 broadband router, QEMU user mode network gateway, Sony PlayStation 2 game console test kit 2.2.1
Network Distance: 6 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT ADDRESS
-   Hops 1-6 are the same as for 89.187.185.184

Nmap scan report for unn-89-187-185-184.cdn77.com (89.187.185.184)
Host is up (0.034s latency).
All 1000 scanned ports on unn-89-187-185-184.cdn77.com (89.187.185.184) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 10 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT       ADDRESS
1   5.86 ms   10.0.2.2
2   271.85 ms modem (192.168.0.1)
3   352.49 ms tukw-dsl-gw75.tukw.qwest.net (63.231.10.75)
4   442.36 ms 63-226-198-81.tukw.qwest.net (63.226.198.81)
5   ...
6   881.15 ms TATA-level3-Seattle2.Level3.net (4.68.127.94)
7   344.80 ms if-ae-20-2.tcore1.sv1-santaclara.as6453.net (64.86.123.95)
8   ... 9
10  197.80 ms unn-89-187-185-184.cdn77.com (89.187.185.184)

172.232.
