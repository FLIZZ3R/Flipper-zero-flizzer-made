proxychains nmap -Pn -sS -A 89.187.185.184
[proxychains] config file found: /etc/proxychains.conf
[proxychains] preloading /usr/lib/x86_64-linux-gnu/libproxychains.so.4
[proxychains] DLL init: proxychains-ng 4.16
Starting Nmap 7.93 ( https://nmap.org ) at 2023-02-23 21:29 PST
Nmap scan report for unn-89-187-185-184.cdn77.com (89.187.185.184)
Host is up (0.011s latency).
All 1000 scanned ports on unn-89-187-185-184.cdn77.com
 (89.187.185.184) are in ignored states.
Not shown: 1000 filtered tcp ports (no-response)
Warning: OSScan results may be unreliable because
 we could not find at least 1 open and 1 closed port
Device type: switch|general purpose|media device
Running: Cisco CatOS 7.X|8.X, HP Tru64 UNIX 5.X, Vantage embedded
OS CPE: cpe:/h:cisco:catalyst_ws-c6506 cpe:/o:cisco:catos:7.6 cpe:/o:cisco:catos:8.3 cpe:/o:hp:tru64:5.1a cpe:/h:vantage:hd7100s
OS details: Cisco Catalyst WS-C6506 switch (CatOS 7.6(16)), Cisco Catalyst switch (CatOS 8.3(2)), HP Tru64 UNIX 5.1A, Vantage HD7100S satellite receiver
Network Distance: 10 hops

TRACEROUTE (using proto 1/icmp)
HOP RTT      ADDRESS
1   2.38 ms  10.0.2.2
2   7.55 ms  _gateway (192.168.0.1)
3   61.33 ms tukw-dsl-gw75.tukw.qwest.net (63.231.10.75)
4   57.28 ms tukw-agw1.inet.qwest.net (63.226.198.81)
5   ...
6   52.93 ms TATA-level3-Seattle2.Level3.net (4.68.127.94)
7   ... 9
10  73.89 ms unn-89-187-185-184.cdn77.com (89.187.185.184)

OS and Service detection performed. Please report any incorrect
 results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 211.82 seconds
